import { Component, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Produto } from '../model/produto';
import { ProdutoService } from '../service/produto.service';
import { CestaService } from '../service/cesta.service';

@Component({
  imports: [CommonModule],
  selector: 'app-resultado-busca',
  templateUrl: './resultado-busca.html',
})
export class ResultadoBusca {
  readonly produtoService = inject(ProdutoService);
  private cestaService = inject(CestaService);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));

  termo = '';
  lista: Produto[] = [];
  erro = false;

  ngOnInit() {
    if (!this.ehNavegador) return;

    this.termo =
      new URLSearchParams(location.search).get('q') ?? localStorage.getItem('buscaTermo') ?? '';
    this.produtoService.buscarPorDescricao(this.termo).subscribe({
      next: dados => (this.lista = dados),
      error: erro => {
        console.error('Falha na busca:', erro);
        this.erro = true;
      },
    });
  }

  verDetalhe(obj: Produto) {
    localStorage.setItem('produto', JSON.stringify(obj));
    location.href = './detalhe?codigo=' + obj.codigo;
  }

  comprar(obj: Produto) {
    if (this.cestaService.adicionar(obj)) location.href = './cesta';
  }
}
