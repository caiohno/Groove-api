import { Component, inject } from '@angular/core';
import { Produto } from '../model/produto';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ProdutoService } from '../service/produto.service';
import { CestaService } from '../service/cesta.service';

@Component({
  imports: [CommonModule],
  selector: 'app-vitrine',
  styleUrl: './vitrine.css',
  templateUrl: './vitrine.html',
})
export class Vitrine {
  readonly produtoService = inject(ProdutoService);
  private cestaService = inject(CestaService);

  soPromocoes = inject(ActivatedRoute).snapshot.routeConfig?.path === 'promo';

  lista: Produto[] = [];
  destaques: Produto[] = [];
  discoHero?: Produto;
  carregando = true;
  erroApi = false;
  aviso = '';

  constructor() {
    this.produtoService.listarApi().subscribe({
      next: todos => {
        this.lista = this.soPromocoes ? todos.filter(p => p.valorPromo > 0) : todos;
        this.carregando = false;
      },
      error: erro => {
        console.error('Falha ao carregar o catálogo:', erro);
        this.erroApi = true;
        this.carregando = false;
      },
    });
    this.produtoService.vitrineApi().subscribe({
      next: destaques => {
        this.destaques = destaques;
        this.discoHero = destaques[destaques.length - 1];
      },
      error: () => {},
    });
  }

  verDetalhe(obj: Produto) {
    localStorage.setItem('produto', JSON.stringify(obj));
    location.href = './detalhe?codigo=' + obj.codigo;
  }

  comprar(obj: Produto) {
    if (this.cestaService.adicionar(obj)) {
      location.href = './cesta';
    } else {
      this.aviso = 'Você já colocou na cesta todas as unidades disponíveis deste disco.';
    }
  }
}
