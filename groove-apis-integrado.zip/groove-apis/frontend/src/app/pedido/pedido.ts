import { Component, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Pedido as PedidoModel } from '../model/pedido';
import { CestaService } from '../service/cesta.service';
import { PedidoService } from '../service/pedido.service';
import { mensagemDeErro } from '../service/erro-api';

@Component({
  imports: [CommonModule],
  selector: 'app-pedido',
  templateUrl: './pedido.html',
})
export class Pedido {
  private cestaService = inject(CestaService);
  private pedidoService = inject(PedidoService);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));
  obj: PedidoModel = new PedidoModel();
  carregando = true;
  erro = '';

  ngOnInit() {
    if (!this.ehNavegador) return;

    const codigo = Number(new URLSearchParams(location.search).get('codigo'));
    if (!codigo) {
      // sem código na URL: cai para o pedido que a lista guardou
      const json = localStorage.getItem('pedidoSelecionado');
      if (!json) {
        location.href = './pedidos';
        return;
      }
      this.obj = JSON.parse(json);
      this.carregando = false;
      return;
    }

    // GET /api/pedido/{codigo}/detalhe: o pedido vem do servidor, não do navegador
    this.pedidoService.buscar(codigo).subscribe({
      next: pedido => {
        this.obj = pedido;
        this.carregando = false;
      },
      error: e => {
        this.erro = mensagemDeErro(e, 'Não foi possível carregar o pedido. Verifique a conexão com a API.');
        this.carregando = false;
      },
    });
  }

  formatar(valor: number): string {
    return this.cestaService.formatar(valor);
  }
}
