import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cliente } from '../model/cliente';
import { ClienteService } from '../service/cliente.service';
import { mensagemDeErro } from '../service/erro-api';

@Component({
  imports: [CommonModule],
  selector: 'app-cadastro',
  templateUrl: './cadastro.html',
})
export class Cadastro {
  private service = inject(ClienteService);

  enviado = false;
  tentouSalvar = false;
  erroApi = '';

  salvar(
    form: HTMLFormElement,
    nome: string,
    cpf: string,
    email: string,
    senha: string,
    telefone: string,
    endereco: string,
  ) {
    this.tentouSalvar = true;
    this.enviado = false;

    if (!form.checkValidity()) {
      return;
    }

    const c = new Cliente();
    c.nome = nome;
    c.cpf = cpf;
    c.email = email;
    c.senha = senha;
    c.telefone = telefone;
    c.endereco = endereco;

    this.erroApi = '';
    this.service.cadastrar(c).subscribe({
      next: () => {
        this.enviado = true;
        this.tentouSalvar = false;
        form.reset();
      },
      error: erro => {
        this.erroApi = mensagemDeErro(erro, 'Não foi possível realizar o cadastro. Verifique a conexão com a API.');
      }
    });
  }
}
