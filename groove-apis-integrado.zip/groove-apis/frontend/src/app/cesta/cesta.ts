import { Component, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { CestaService } from '../service/cesta.service';
import { PedidoService } from '../service/pedido.service';
import { ClienteService } from '../service/cliente.service';
import { mensagemDeErro } from '../service/erro-api';

@Component({
  imports: [CommonModule],
  selector: 'app-cesta',
  styleUrl: './cesta.css',
  templateUrl: './cesta.html',
})
export class Cesta {
  private service = inject(CestaService);
  private pedidoService = inject(PedidoService);
  private clienteService = inject(ClienteService);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));
  mensagem: string = '';
  tipoMensagem: string = 'warning';
  precisaLogin = false;
  enviando = false;

  ngOnInit() {
    if (!this.ehNavegador) return;
    // preço e estoque podem ter mudado desde que o item entrou na cesta
    this.service.sincronizar().subscribe(avisos => {
      if (avisos.length) this.avisar(avisos.join(' '), 'warning');
    });
  }

  get lista() {
    return this.service.cesta.itens;
  }

  get valorCesta(): number {
    return this.service.total();
  }

  formatar(valor: number): string {
    return this.service.formatar(valor);
  }

  private avisar(texto: string, tipo: string) {
    this.mensagem = texto;
    this.tipoMensagem = tipo;
    this.precisaLogin = false;
  }

  remover(codigo: number) {
    this.service.remover(codigo);
    this.mensagem = '';
  }

  aumentar(codigo: number) {
    if (this.service.alterarQtd(codigo, 1)) {
      this.mensagem = '';
    } else {
      this.avisar('Quantidade máxima em estoque atingida.', 'warning');
    }
  }

  diminuir(codigo: number) {
    this.service.alterarQtd(codigo, -1);
    this.mensagem = '';
  }

  limpar() {
    this.service.limpar();
    this.avisar('Cesta esvaziada.', 'secondary');
  }

  finalizar() {
    if (this.lista.length === 0) {
      this.avisar('Sua cesta está vazia.', 'secondary');
      return;
    }
    const cliente = this.clienteService.clienteLogado();
    if (!cliente?.codigo) {
      this.avisar('Entre na sua conta para finalizar o pedido.', 'warning');
      this.precisaLogin = true;
      return;
    }

    this.enviando = true;
    this.pedidoService.finalizar(cliente.codigo, this.lista).subscribe({
      next: pedido => {
        this.enviando = false;
        this.service.limpar();
        this.avisar(`Pedido #${pedido.numero} realizado com sucesso!`, 'success');
      },
      error: erro => {
        this.enviando = false;
        this.avisar(
          mensagemDeErro(erro, 'Não foi possível finalizar o pedido. Verifique a conexão com a API e tente novamente.'),
          'warning',
        );
        // estoque pode ter mudado: atualiza a cesta com os dados do servidor
        this.service.sincronizar().subscribe();
      },
    });
  }
}
