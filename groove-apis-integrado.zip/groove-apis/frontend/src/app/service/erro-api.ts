/**
 * Extrai a mensagem de erro devolvida pelo backend ({"mensagem": "..."}),
 * seja o corpo texto (responseType: 'text') ou JSON. Sem corpo = API fora do ar.
 */
export function mensagemDeErro(erro: any, padrao: string): string {
  const corpo = erro?.error;
  if (!corpo) return padrao;
  if (typeof corpo === 'string') {
    try {
      return JSON.parse(corpo).mensagem ?? padrao;
    } catch {
      return padrao;
    }
  }
  return corpo.mensagem ?? padrao;
}
