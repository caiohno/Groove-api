/**
 * Configure aqui a URL raiz do backend Spring.
 * Exemplo: http://localhost:8081
 * Não inclua /api no final.
 */
export const API_BASE_URL = 'http://localhost:8081';
