import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { Cliente } from '../model/cliente';
import { API_BASE_URL } from './api.config';

export interface ClienteApi {
  codigo?: number;
  nome: string;
  email: string;
  senha?: string;
  documento?: string;
  telefone?: string;
  logradouro?: string;
}

@Injectable({ providedIn: 'root' })
export class ClienteService {
  private http = inject(HttpClient);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));
  private readonly url = `${API_BASE_URL}/api/cliente`;

  buscar(codigo: number): Observable<ClienteApi> {
    return this.http.get<ClienteApi>(`${this.url}/${codigo}`);
  }

  cadastrar(cliente: Cliente): Observable<string> {
    return this.http.post(this.url, this.paraApi(cliente), { responseType: 'text' });
  }

  alterar(cliente: Cliente & { codigo?: number }): Observable<string> {
    return this.http.put(this.url, this.paraApi(cliente), { responseType: 'text' });
  }

  excluir(codigo: number): Observable<string> {
    return this.http.delete(`${this.url}/${codigo}`, { responseType: 'text' });
  }

  autenticar(email: string, senha: string): Observable<ClienteApi | null> {
    return this.http.post<ClienteApi>(`${this.url}/login`, { email, senha }).pipe(
      map(cliente => cliente && Object.keys(cliente).length ? cliente : null)
    );
  }

  resetarSenha(email: string): Observable<string> {
    return this.http.patch(`${this.url}/resetarSenha`, { email }, { responseType: 'text' });
  }

  alterarSenha(email: string, documento: string, senha: string): Observable<string> {
    return this.http.patch(`${this.url}/alterarSenha`, { email, documento, senha }, { responseType: 'text' });
  }

  /** Atualiza o cliente guardado no navegador (depois de alterar os dados). */
  salvarLogado(cliente: ClienteApi) {
    if (!this.ehNavegador) return;
    localStorage.setItem('clienteLogado', JSON.stringify(cliente));
  }

  sair() {
    if (!this.ehNavegador) return;
    localStorage.removeItem('clienteLogado');
  }

  clienteLogado(): ClienteApi | null {
    if (!this.ehNavegador) return null;
    try {
      const json = localStorage.getItem('clienteLogado');
      return json ? JSON.parse(json) : null;
    } catch { return null; }
  }

  private paraApi(c: Cliente & { codigo?: number }): Record<string, unknown> {
    return {
      ...(c.codigo !== undefined ? { codigo: c.codigo } : {}),
      nome: c.nome,
      email: c.email,
      senha: c.senha,
      documento: (c.cpf ?? '').replace(/\D/g, ''),
      telefone: c.telefone,
      logradouro: c.endereco,
    };
  }
}
