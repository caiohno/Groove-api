import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Produto } from '../model/produto';
import { ItemCesta } from '../model/item-cesta';
import { Cesta } from '../model/cesta';
import { ProdutoService } from './produto.service';
import { Observable, catchError, forkJoin, map, of } from 'rxjs';

const CHAVE_STORAGE = 'cesta';

@Injectable({ providedIn: 'root' })
export class CestaService {
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));
  private produtoService = inject(ProdutoService);
  cesta: Cesta = new Cesta();

  constructor() {
    this.carregar();
  }

  private carregar() {
    if (!this.ehNavegador) return;
    const json = localStorage.getItem(CHAVE_STORAGE);
    if (json) {
      const obj = JSON.parse(json);
      this.cesta.itens = obj.itens ?? [];
    }
  }

  private salvar() {
    if (!this.ehNavegador) return;
    localStorage.setItem(CHAVE_STORAGE, JSON.stringify(this.cesta));
  }

  private preco(produto: Produto): number {
    return produto.valorPromo > 0 ? produto.valorPromo : produto.valor;
  }

  adicionar(produto: Produto, qtd: number = 1): boolean {
    const existente = this.cesta.itens.find(i => i.produto.codigo === produto.codigo);
    const jaNaCesta = existente ? existente.qtd : 0;
    if (jaNaCesta + qtd > produto.quantidade) return false;

    if (existente) {
      existente.qtd += qtd;
      existente.valorTotal = existente.qtd * this.preco(produto);
    } else {
      const item = new ItemCesta(produto);
      item.qtd = qtd;
      item.valorTotal = qtd * this.preco(produto);
      this.cesta.itens.push(item);
    }
    this.salvar();
    return true;
  }

  remover(codigo: number) {
    this.cesta.itens = this.cesta.itens.filter(i => i.produto.codigo !== codigo);
    this.salvar();
  }

  alterarQtd(codigo: number, delta: number): boolean {
    const item = this.cesta.itens.find(i => i.produto.codigo === codigo);
    if (!item) return false;
    const nova = item.qtd + delta;
    if (nova > item.produto.quantidade) return false;
    item.qtd = Math.max(1, nova);
    item.valorTotal = item.qtd * this.preco(item.produto);
    this.salvar();
    return true;
  }

  /**
   * Atualiza preço e estoque dos itens com os dados atuais da API.
   * Remove da cesta produtos esgotados/excluídos e ajusta a quantidade ao estoque.
   * Retorna os avisos (o que foi alterado) para mostrar ao cliente.
   */
  sincronizar(): Observable<string[]> {
    if (!this.ehNavegador || this.cesta.itens.length === 0) return of([]);
    const itens = [...this.cesta.itens];
    return forkJoin(
      itens.map(i => this.produtoService.buscarApi(i.produto.codigo).pipe(catchError(() => of(null)))),
    ).pipe(
      map(produtos => {
        const avisos: string[] = [];
        const novos: ItemCesta[] = [];
        itens.forEach((item, idx) => {
          const atual = produtos[idx];
          if (!atual) { novos.push(item); return; } // API fora do ar: mantém como está
          if (atual.codigo <= 0 || atual.quantidade <= 0) {
            avisos.push(`"${item.produto.nome}" não está mais disponível e saiu da cesta.`);
            return;
          }
          if (item.qtd > atual.quantidade) {
            avisos.push(`A quantidade de "${atual.nome}" foi ajustada para ${atual.quantidade} (estoque).`);
            item.qtd = atual.quantidade;
          }
          item.produto = atual;
          item.valorTotal = item.qtd * this.preco(atual);
          novos.push(item);
        });
        this.cesta.itens = novos;
        this.salvar();
        return avisos;
      }),
    );
  }

  limpar() {
    this.cesta.itens = [];
    this.salvar();
  }

  total(): number {
    return this.cesta.itens.reduce((soma, i) => soma + i.valorTotal, 0);
  }

  quantidadeItens(): number {
    return this.cesta.itens.reduce((soma, i) => soma + i.qtd, 0);
  }

  formatar(valor: number): string {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
}
