import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_BASE_URL } from './api.config';
import { Pedido } from '../model/pedido';
import { ItemPedido } from '../model/item-pedido';
import { ItemCesta } from '../model/item-cesta';
import { Produto } from '../model/produto';

interface ItemPedidoApi {
  codigoProduto: number;
  nomeProduto: string;
  quantidade: number;
  valorUnitario: number;
  valorTotal: number;
}

interface PedidoApi {
  codigoPedido: number;
  codigoCliente: number;
  dataPedido: string | null; // yyyy-MM-dd
  valorTotal: number;
  entrega?: string;
  obs?: string;
  itens: ItemPedidoApi[];
}

@Injectable({ providedIn: 'root' })
export class PedidoService {
  private http = inject(HttpClient);
  private readonly url = `${API_BASE_URL}/api/pedido`;

  /** POST /api/pedido/finalizar: grava pedido + itens e baixa o estoque no servidor. */
  finalizar(codigoCliente: number, itens: ItemCesta[]): Observable<Pedido> {
    const corpo = {
      codigoCliente,
      itens: itens.map(i => ({ codigoProduto: i.produto.codigo, quantidade: i.qtd })),
    };
    return this.http.post<PedidoApi>(`${this.url}/finalizar`, corpo).pipe(map(p => this.paraPedido(p)));
  }

  /** GET /api/pedidos/cliente/{codigo}: histórico do cliente, mais novos primeiro. */
  listarDoCliente(codigoCliente: number): Observable<Pedido[]> {
    return this.http
      .get<PedidoApi[]>(`${API_BASE_URL}/api/pedidos/cliente/${codigoCliente}`)
      .pipe(map(lista => lista.map(p => this.paraPedido(p))));
  }

  /** GET /api/pedido/{codigo}/detalhe */
  buscar(codigo: number): Observable<Pedido> {
    return this.http.get<PedidoApi>(`${this.url}/${codigo}/detalhe`).pipe(map(p => this.paraPedido(p)));
  }

  private paraPedido(api: PedidoApi): Pedido {
    const pedido = new Pedido();
    pedido.numero = api.codigoPedido;
    pedido.data = this.formatarData(api.dataPedido);
    pedido.status = 'Confirmado';
    pedido.total = api.valorTotal;
    pedido.itens = (api.itens ?? []).map(i => {
      const item = new ItemPedido();
      item.produto = Object.assign(new Produto(), { codigo: i.codigoProduto, nome: i.nomeProduto });
      item.qtd = i.quantidade;
      item.valorUnitario = i.valorUnitario;
      item.valorTotal = i.valorTotal;
      return item;
    });
    return pedido;
  }

  private formatarData(iso: string | null): string {
    if (!iso) return '';
    const [ano, mes, dia] = iso.substring(0, 10).split('-');
    return `${dia}/${mes}/${ano}`;
  }
}
