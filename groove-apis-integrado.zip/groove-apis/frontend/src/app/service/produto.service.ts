import { Injectable, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable, map, of, tap } from 'rxjs';
import { API_BASE_URL } from './api.config';
import { Produto } from '../model/produto';

@Injectable({ providedIn: 'root' })
export class ProdutoService {
  private http = inject(HttpClient);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));
  private readonly url = `${API_BASE_URL}/api/produto`;

  /** Última lista recebida da API (o catálogo mora no banco, não no frontend). */
  lista: Produto[] = [];

  readonly previas: Record<number, { faixa: string; url: string }> = {
  "1": {
    "faixa": "Wish You Were Here",
    "url": "https://www.deezer.com/track/116914042"
  },
  "2": {
    "faixa": "Sgt. Pepper's Lonely Hearts Club Band (Remastered 2009)",
    "url": "https://www.deezer.com/track/116348670"
  },
  "3": {
    "faixa": "Bad (2012 Remaster)",
    "url": "https://www.deezer.com/track/59509421"
  },
  "4": {
    "faixa": "Heart-Shaped Box",
    "url": "https://www.deezer.com/track/70466227"
  },
  "5": {
    "faixa": "Dreams (2004 Remaster)",
    "url": "https://www.deezer.com/track/63480987"
  },
  "6": {
    "faixa": "So What (feat. John Coltrane, Cannonball Adderley & Bill Evans)",
    "url": "https://www.deezer.com/track/15599529"
  },
  "7": {
    "faixa": "Purple Rain",
    "url": "https://www.deezer.com/track/2806039702"
  },
  "8": {
    "faixa": "Bohemian Rhapsody",
    "url": "https://www.deezer.com/track/4091937401"
  },
  "9": {
    "faixa": "Doo Wop (That Thing)",
    "url": "https://www.deezer.com/track/400418902"
  },
  "10": {
    "faixa": "Tudo O Que Você Podia Ser",
    "url": "https://www.deezer.com/track/716531362"
  },
  "11": {
    "faixa": "Será",
    "url": "https://www.deezer.com/track/3530731"
  },
  "12": {
    "faixa": "Selim",
    "url": "https://www.deezer.com/track/80134952"
  },
  "13": {
    "faixa": "Jorge da Capadócia",
    "url": "https://www.deezer.com/track/140639829"
  },
  "14": {
    "faixa": "One More Time",
    "url": "https://www.deezer.com/track/3135553"
  },
  "15": {
    "faixa": "Back In Black",
    "url": "https://www.deezer.com/track/92720046"
  },
  "16": {
    "faixa": "Nuthin' But A \"G\" Thang",
    "url": "https://www.deezer.com/track/2132919007"
  },
  "17": {
    "faixa": "Blue Suede Shoes",
    "url": "https://www.deezer.com/track/69070922"
  },
  "18": {
    "faixa": "Back To Black",
    "url": "https://www.deezer.com/track/2176856"
  },
  "19": {
    "faixa": "Formation",
    "url": "https://www.deezer.com/track/669486732"
  },
  "20": {
    "faixa": "Wannabe",
    "url": "https://www.deezer.com/track/3133738"
  }
};

  /** Converte o JSON da API (nome/descritivo/valor/...) no modelo do frontend. */
  private paraProduto(api: any): Produto {
    return Object.assign(new Produto(), {
      codigo: api.codigo ?? 0,
      nome: api.nome ?? api.descricao ?? '',
      descritivo: api.descritivo ?? '',
      keywords: api.keywords ?? '',
      valor: api.valor ?? 0,
      valorPromo: api.valorPromo ?? 0,
      quantidade: api.quantidade ?? 0,
      destaque: api.destaque ?? 0,
    });
  }

  private paraLista(dados: any[]): Produto[] {
    return (dados ?? []).map(d => this.paraProduto(d));
  }

  /** GET /api/produtos */
  listarApi(): Observable<Produto[]> {
    if (!this.ehNavegador) return of([]);
    return this.http.get<any[]>(`${API_BASE_URL}/api/produtos`).pipe(
      map(d => this.paraLista(d)),
      tap(lista => (this.lista = lista)),
    );
  }

  /** GET /api/produto/vitrine (produtos em destaque) */
  vitrineApi(): Observable<Produto[]> {
    if (!this.ehNavegador) return of([]);
    return this.http.get<any[]>(`${this.url}/vitrine`).pipe(map(d => this.paraLista(d)));
  }

  /** GET /api/produto/{codigo}; código 0 = não encontrado */
  buscarApi(codigo: number): Observable<Produto> {
    if (!this.ehNavegador) return of(new Produto());
    return this.http.get<any>(`${this.url}/${codigo}`).pipe(map(d => this.paraProduto(d)));
  }

  /** GET /api/produto/busca/{termo} */
  buscarPorDescricao(termo: string): Observable<Produto[]> {
    if (!this.ehNavegador) return of([]);
    return this.http
      .get<any[]>(`${this.url}/busca/${encodeURIComponent(termo)}`)
      .pipe(map(d => this.paraLista(d)));
  }

  cadastrarApi(produto: Produto): Observable<string> {
    return this.http.post(this.url, produto, { responseType: 'text' });
  }

  alterarApi(produto: Produto): Observable<string> {
    return this.http.put(this.url, produto, { responseType: 'text' });
  }

  excluirApi(codigo: number): Observable<string> {
    return this.http.delete(`${this.url}/${codigo}`, { responseType: 'text' });
  }

  calcularDesconto(valor: number, valorPromo: number): number {
    return valor > 0 && valorPromo > 0 && valorPromo < valor
      ? Math.round((1 - valorPromo / valor) * 100) : 0;
  }

  formatar(valor: number): string {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  titulo(produto: Produto): string { return produto.nome.split(' - ')[0]; }
  artista(produto: Produto): string { return produto.nome.split(' - ').slice(1).join(' - '); }
}
