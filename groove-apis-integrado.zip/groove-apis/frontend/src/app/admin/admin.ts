import { Component, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Produto } from '../model/produto';
import { ProdutoService } from '../service/produto.service';
import { mensagemDeErro } from '../service/erro-api';

/**
 * Catálogo (admin): usa os endpoints de produto que faltavam na interface —
 * POST /api/produto, PUT /api/produto e DELETE /api/produto/{codigo}.
 *
 * Atenção: a API não tem autenticação nem papel de administrador, então esta
 * tela não é uma barreira de segurança — qualquer um que alcance a API pode
 * fazer o mesmo. Para valer, o controle precisa existir no backend.
 */
@Component({
  imports: [CommonModule],
  selector: 'app-admin',
  templateUrl: './admin.html',
})
export class Admin {
  readonly produtoService = inject(ProdutoService);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));

  lista: Produto[] = [];
  carregando = true;
  erro = '';
  aviso = '';

  emEdicao: Produto | null = null;
  salvando = false;
  confirmandoExclusao: number | null = null;

  ngOnInit() {
    if (!this.ehNavegador) return;
    this.recarregar();
  }

  private recarregar() {
    this.carregando = true;
    this.produtoService.listarApi().subscribe({
      next: lista => {
        this.lista = lista;
        this.carregando = false;
      },
      error: e => {
        this.erro = mensagemDeErro(e, 'Não foi possível carregar o catálogo. Verifique a conexão com a API.');
        this.carregando = false;
      },
    });
  }

  novo() {
    this.emEdicao = new Produto();
    this.aviso = '';
    this.erro = '';
  }

  editar(produto: Produto) {
    this.emEdicao = Object.assign(new Produto(), produto);
    this.aviso = '';
    this.erro = '';
  }

  cancelar() {
    this.emEdicao = null;
  }

  /** POST /api/produto quando é novo, PUT /api/produto quando já tem código. */
  salvar(
    nome: string,
    descritivo: string,
    keywords: string,
    valor: string,
    valorPromo: string,
    quantidade: string,
    destaque: string,
  ) {
    if (!this.emEdicao) return;
    this.erro = '';
    this.aviso = '';

    if (!nome.trim()) {
      this.erro = 'Informe o nome do disco (ex: "Álbum - Artista").';
      return;
    }
    const numero = (texto: string) => {
      const n = Number(String(texto).replace(',', '.'));
      return Number.isFinite(n) && n >= 0 ? n : 0;
    };

    const produto = Object.assign(new Produto(), {
      codigo: this.emEdicao.codigo,
      nome: nome.trim(),
      descritivo: descritivo.trim(),
      keywords: keywords.trim(),
      valor: numero(valor),
      valorPromo: numero(valorPromo),
      quantidade: Math.trunc(numero(quantidade)),
      destaque: Math.trunc(numero(destaque)),
    });

    if (produto.valorPromo > 0 && produto.valorPromo >= produto.valor) {
      this.erro = 'O valor promocional precisa ser menor que o valor normal.';
      return;
    }

    const novo = !produto.codigo;
    this.salvando = true;
    const chamada = novo
      ? this.produtoService.cadastrarApi(produto)
      : this.produtoService.alterarApi(produto);

    chamada.subscribe({
      next: resposta => {
        this.salvando = false;
        if (/não encontrado/i.test(resposta)) {
          this.erro = 'A API não encontrou este produto. Recarregue a lista.';
          return;
        }
        this.aviso = novo
          ? `Disco cadastrado! ${resposta}`
          : `Disco ${produto.codigo} alterado com sucesso.`;
        this.emEdicao = null;
        this.recarregar();
      },
      error: e => {
        this.salvando = false;
        this.erro = mensagemDeErro(e, 'Não foi possível salvar o disco. Verifique a conexão com a API.');
      },
    });
  }

  /** DELETE /api/produto/{codigo} */
  excluir(codigo: number) {
    this.erro = '';
    this.aviso = '';
    this.produtoService.excluirApi(codigo).subscribe({
      next: resposta => {
        this.confirmandoExclusao = null;
        this.aviso = /não encontrado/i.test(resposta)
          ? `O disco ${codigo} já não existia na API.`
          : `Disco ${codigo} removido.`;
        this.recarregar();
      },
      error: e => {
        this.confirmandoExclusao = null;
        this.erro = mensagemDeErro(e, 'Não foi possível remover o disco.');
      },
    });
  }

  formatar(valor: number): string {
    return this.produtoService.formatar(valor);
  }
}
