import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Admin } from './admin';

describe('Admin', () => {
  let component: Admin;
  let fixture: ComponentFixture<Admin>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Admin],
    }).compileComponents();

    fixture = TestBed.createComponent(Admin);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('abre o formulário de novo disco com os campos vazios', () => {
    component.novo();
    expect(component.emEdicao?.codigo).toBe(0);
    expect(component.emEdicao?.nome).toBe('');
  });

  it('recusa promoção maior ou igual ao valor normal', () => {
    component.novo();
    component.salvar('Disco - Artista', '', '', '100', '100', '1', '0');
    expect(component.erro).toContain('menor que o valor normal');
  });

  it('recusa disco sem nome', () => {
    component.novo();
    component.salvar('   ', '', '', '10', '0', '1', '0');
    expect(component.erro).toContain('Informe o nome');
  });
});
