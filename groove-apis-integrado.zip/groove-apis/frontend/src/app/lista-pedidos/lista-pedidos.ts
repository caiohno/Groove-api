import { Component, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Pedido } from '../model/pedido';
import { PedidoService } from '../service/pedido.service';
import { CestaService } from '../service/cesta.service';
import { ClienteService } from '../service/cliente.service';
import { mensagemDeErro } from '../service/erro-api';

@Component({
  imports: [CommonModule],
  selector: 'app-lista-pedidos',
  templateUrl: './lista-pedidos.html',
})
export class ListaPedidos {
  private service = inject(PedidoService);
  private cestaService = inject(CestaService);
  private clienteService = inject(ClienteService);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));

  lista: Pedido[] = [];
  carregando = true;
  naoLogado = false;
  erro = '';

  ngOnInit() {
    if (!this.ehNavegador) return;
    const cliente = this.clienteService.clienteLogado();
    if (!cliente?.codigo) {
      this.carregando = false;
      this.naoLogado = true;
      return;
    }
    this.service.listarDoCliente(cliente.codigo).subscribe({
      next: pedidos => {
        this.lista = pedidos;
        this.carregando = false;
      },
      error: e => {
        this.erro = mensagemDeErro(e, 'Não foi possível carregar seus pedidos. Verifique a conexão com a API.');
        this.carregando = false;
      },
    });
  }

  formatar(valor: number): string {
    return this.cestaService.formatar(valor);
  }

  verDetalhe(pedido: Pedido) {
    // o código vai na URL: a tela de detalhe recarrega o pedido pela API
    localStorage.setItem('pedidoSelecionado', JSON.stringify(pedido));
    location.href = './pedido?codigo=' + pedido.numero;
  }
}
