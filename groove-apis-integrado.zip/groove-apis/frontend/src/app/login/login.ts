import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClienteService } from '../service/cliente.service';

@Component({ imports: [CommonModule], selector: 'app-login', templateUrl: './login.html' })
export class Login {
  private service = inject(ClienteService);
  erro = false;
  falhaApi = false;
  carregando = false;

  entrar(email: string, senha: string) {
    this.carregando = true;
    this.erro = false;
    this.falhaApi = false;
    this.service.autenticar(email, senha).subscribe({
      next: cliente => {
        this.carregando = false;
        this.erro = !cliente;
        if (cliente) {
          localStorage.setItem('clienteLogado', JSON.stringify(cliente));
          location.href = './';
        }
      },
      error: (e) => { this.carregando = false; if (e?.status === 0) this.falhaApi = true; else this.erro = true; }
    });
  }
}
