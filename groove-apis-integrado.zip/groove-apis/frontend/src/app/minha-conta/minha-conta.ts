import { Component, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Cliente } from '../model/cliente';
import { ClienteApi, ClienteService } from '../service/cliente.service';
import { mensagemDeErro } from '../service/erro-api';

/**
 * Minha conta: usa os endpoints de cliente que faltavam na interface —
 * GET /api/cliente/{codigo}, PUT /api/cliente, DELETE /api/cliente/{codigo}
 * e PATCH /api/cliente/alterarSenha.
 */
@Component({
  imports: [CommonModule],
  selector: 'app-minha-conta',
  templateUrl: './minha-conta.html',
})
export class MinhaConta {
  private service = inject(ClienteService);
  private ehNavegador = isPlatformBrowser(inject(PLATFORM_ID));

  dados: ClienteApi = { nome: '', email: '' };
  carregando = true;
  naoLogado = false;
  erro = '';
  salvo = '';

  erroSenha = '';
  senhaTrocada = '';
  trocandoSenha = false;

  confirmandoExclusao = false;
  erroExclusao = '';

  ngOnInit() {
    if (!this.ehNavegador) return;
    const logado = this.service.clienteLogado();
    if (!logado?.codigo) {
      this.carregando = false;
      this.naoLogado = true;
      return;
    }
    // GET /api/cliente/{codigo}: os dados vêm do servidor, não do navegador
    this.service.buscar(logado.codigo).subscribe({
      next: cliente => {
        if (cliente?.codigo) {
          this.dados = cliente;
          this.service.salvarLogado(cliente);
        } else {
          this.erro = 'Não encontramos sua conta na API. Entre novamente.';
        }
        this.carregando = false;
      },
      error: e => {
        this.erro = mensagemDeErro(e, 'Não foi possível carregar seus dados. Verifique a conexão com a API.');
        this.carregando = false;
      },
    });
  }

  /** PUT /api/cliente — senha em branco mantém a senha atual. */
  salvar(nome: string, email: string, documento: string, telefone: string, logradouro: string) {
    this.erro = '';
    this.salvo = '';
    if (!nome.trim() || !email.trim()) {
      this.erro = 'Informe pelo menos nome e e-mail.';
      return;
    }
    const cliente = new Cliente() as Cliente & { codigo?: number };
    cliente.codigo = this.dados.codigo;
    cliente.nome = nome.trim();
    cliente.email = email.trim();
    cliente.cpf = documento;
    cliente.telefone = telefone;
    cliente.endereco = logradouro;
    cliente.senha = '';

    this.service.alterar(cliente).subscribe({
      next: resposta => {
        if (/não encontrado/i.test(resposta)) {
          this.erro = 'Sua conta não foi encontrada na API.';
          return;
        }
        this.salvo = 'Dados atualizados com sucesso!';
        this.dados = {
          ...this.dados,
          nome: cliente.nome,
          email: cliente.email,
          documento: (documento ?? '').replace(/\D/g, ''),
          telefone,
          logradouro,
        };
        this.service.salvarLogado(this.dados);
      },
      error: e => {
        this.erro = mensagemDeErro(e, 'Não foi possível salvar seus dados. Verifique a conexão com a API.');
      },
    });
  }

  /** PATCH /api/cliente/alterarSenha — a senha atual vai no campo "documento". */
  trocarSenha(atual: string, nova: string, confirmacao: string, form: HTMLFormElement) {
    this.erroSenha = '';
    this.senhaTrocada = '';
    if (!atual || !nova) {
      this.erroSenha = 'Informe a senha atual e a nova senha.';
      return;
    }
    if (nova !== confirmacao) {
      this.erroSenha = 'A confirmação não é igual à nova senha.';
      return;
    }
    this.trocandoSenha = true;
    this.service.alterarSenha(this.dados.email, atual, nova).subscribe({
      next: () => {
        this.trocandoSenha = false;
        this.senhaTrocada = 'Senha alterada com sucesso!';
        form.reset();
      },
      error: e => {
        this.trocandoSenha = false;
        this.erroSenha = mensagemDeErro(e, 'Não foi possível alterar a senha.');
      },
    });
  }

  /** DELETE /api/cliente/{codigo} */
  excluir() {
    this.erroExclusao = '';
    if (!this.dados.codigo) return;
    this.service.excluir(this.dados.codigo).subscribe({
      next: resposta => {
        if (/não encontrado/i.test(resposta)) {
          this.erroExclusao = 'Sua conta já não existe mais na API.';
          return;
        }
        this.service.sair();
        location.href = './';
      },
      error: e => {
        this.erroExclusao = mensagemDeErro(e, 'Não foi possível excluir a conta.');
      },
    });
  }
}
