import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MinhaConta } from './minha-conta';

describe('MinhaConta', () => {
  let component: MinhaConta;
  let fixture: ComponentFixture<MinhaConta>;

  beforeEach(async () => {
    localStorage.removeItem('clienteLogado');
    await TestBed.configureTestingModule({
      imports: [MinhaConta],
    }).compileComponents();

    fixture = TestBed.createComponent(MinhaConta);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('pede login quando não há cliente no navegador', () => {
    expect(component.naoLogado).toBe(true);
    expect((fixture.nativeElement as HTMLElement).textContent).toContain('Entre na sua conta');
  });
});
