import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { inject } from '@angular/core';
import { ClienteService } from '../service/cliente.service';
import { mensagemDeErro } from '../service/erro-api';

@Component({
  imports: [CommonModule],
  selector: 'app-reenvio',
  templateUrl: './reenvio.html',
})
export class Reenvio {
  private clienteService = inject(ClienteService);
  mensagemErro = '';
  enviado = false;
  erro = false;
  emailEnviado = '';

  enviar(email: string) {
    const valor = email.trim();
    const valido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor);
    this.erro = !valido;
    this.mensagemErro = '';
    if (!valido) return;
    this.clienteService.resetarSenha(valor).subscribe({
      next: () => {
        this.enviado = true;
        this.emailEnviado = valor;
      },
      error: erro => {
        this.mensagemErro = mensagemDeErro(erro, 'Não foi possível solicitar a redefinição de senha.');
      }
    });
  }

  tentarNovamente() {
    this.enviado = false;
    this.erro = false;
    this.emailEnviado = '';
    this.mensagemErro = '';
  }
}
