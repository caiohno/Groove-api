import { ItemCesta } from './item-cesta';
import { Produto } from './produto';

describe('ItemCesta', () => {
  it('should create an instance', () => {
    expect(new ItemCesta(new Produto())).toBeTruthy();
  });

  it('usa o valor promocional quando existe', () => {
    const produto = Object.assign(new Produto(), { valor: 100, valorPromo: 80 });
    expect(new ItemCesta(produto).valorTotal).toBe(80);
  });

  it('usa o valor normal quando não há promoção', () => {
    const produto = Object.assign(new Produto(), { valor: 100, valorPromo: 0 });
    expect(new ItemCesta(produto).valorTotal).toBe(100);
  });
});
