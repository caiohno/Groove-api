/**
 * Dublê da API da Lojinha — só para TESTE e DESENVOLVIMENTO.
 *
 * Reproduz, em memória, exatamente o contrato do backend Groovy + Spring Boot
 * (status, corpo, mensagens e regras de negócio). Serve para:
 *   - rodar o frontend sem precisar de JDK/Maven;
 *   - rodar os testes (tools/testar-api.mjs e os testes de tela) em CI.
 *
 * NÃO é o backend de produção: não tem banco, não tem persistência e não deve
 * ser publicado. O backend real é backend/ (porta 8081).
 *
 *   node tools/api-stub.mjs [--port 8081] [--silencioso]
 */
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const AQUI = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const PORTA = Number(args[args.indexOf('--port') + 1]) || 8081;
const SILENCIOSO = args.includes('--silencioso');
const ORIGENS = (process.env.CORS_ORIGINS ?? 'http://localhost:4200').split(',').map(o => o.trim());

const CATALOGO = JSON.parse(readFileSync(join(AQUI, 'catalogo-inicial.json'), 'utf8'));

// ---------------------------------------------------------------- banco em memória
const bd = {
  produtos: [],
  clientes: [],
  pedidos: [],
  itensPedido: [],
  seq: { produto: 0, cliente: 0, pedido: 0, item: 0 },
};

function semear() {
  bd.produtos = CATALOGO.map(d => ({
    codigo: ++bd.seq.produto,
    nome: d.nome,
    descritivo: d.descritivo,
    keywords: d.keywords,
    valor: d.valor,
    valorPromo: d.valorPromo,
    quantidade: d.quantidade,
    destaque: d.destaque,
  }));
}
semear();

/** Igual a Produto.precoAtual() no backend. */
const precoAtual = p => (p.valorPromo > 0 ? p.valorPromo : p.valor);
const duasCasas = v => Math.round(v * 100) / 100;

/** O JPA devolve a entidade inteira; "descricao" é o apelido de "nome" (getDescricao). */
function produtoJson(p) {
  if (!p) {
    return {
      codigo: 0, nome: null, descritivo: null, keywords: null,
      valor: 0, valorPromo: 0, quantidade: 0, destaque: 0, descricao: null,
    };
  }
  return { ...p, descricao: p.nome };
}

/** A senha é WRITE_ONLY no backend: entra no POST/PUT, nunca sai na resposta. */
function clienteJson(c) {
  if (!c) {
    return { codigo: 0, nome: null, telefone: null, documento: null, logradouro: null, email: null, ativo: 0 };
  }
  const { senha, ...resto } = c;
  return resto;
}

function pedidoJson(p) {
  if (!p) return { codigoPedido: 0, valorTotal: 0, entrega: null, obs: null, dataPedido: null, codigoCliente: 0 };
  return {
    codigoPedido: p.codigoPedido,
    valorTotal: p.valorTotal,
    entrega: p.entrega ?? null,
    obs: p.obs ?? null,
    dataPedido: p.dataPedido,
    codigoCliente: p.codigoCliente,
  };
}

/** Pedido + itens, no formato que o frontend consome (PedidoService.paraMapa). */
function pedidoComItens(p) {
  const itens = bd.itensPedido
    .filter(i => i.codigoPedido === p.codigoPedido)
    .map(i => {
      const produto = bd.produtos.find(x => x.codigo === i.codigoProduto);
      return {
        codigoProduto: i.codigoProduto,
        nomeProduto: produto?.nome ?? 'Produto removido',
        quantidade: i.quantidade,
        valorUnitario: i.valor,
        valorTotal: duasCasas(i.valor * i.quantidade),
      };
    });
  return {
    codigoPedido: p.codigoPedido,
    codigoCliente: p.codigoCliente,
    dataPedido: p.dataPedido,
    valorTotal: p.valorTotal,
    entrega: p.entrega ?? null,
    obs: p.obs ?? null,
    itens,
  };
}

const hoje = () => new Date().toISOString().slice(0, 10);

/** Mesma normalização do ProdutoController: sem acentos, minúsculas. */
const normalizar = t =>
  (t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

class RegraNegocio extends Error {}
const regra = m => { throw new RegraNegocio(m); };
const naoVazio = s => typeof s === 'string' && s.trim().length > 0;

// ---------------------------------------------------------------- rotas
const rotas = [];
const rota = (metodo, padrao, acao) => rotas.push({ metodo, padrao, acao });

// -- Cliente ------------------------------------------------------
rota('GET', /^\/api\/cliente\/(\d+)$/, ([id]) =>
  json(clienteJson(bd.clientes.find(c => c.codigo === +id))));

rota('POST', /^\/api\/cliente$/, (_, corpo) => {
  if (!naoVazio(corpo.nome) || !naoVazio(corpo.email) || !naoVazio(corpo.senha)) {
    regra('Informe nome, e-mail e senha.');
  }
  const email = corpo.email.trim();
  if (bd.clientes.some(c => c.email === email)) regra('Já existe um cadastro com este e-mail.');
  const cliente = {
    codigo: ++bd.seq.cliente,
    nome: corpo.nome,
    telefone: corpo.telefone ?? null,
    documento: corpo.documento ?? null,
    senha: corpo.senha,
    logradouro: corpo.logradouro ?? null,
    email,
    ativo: 1,
  };
  bd.clientes.push(cliente);
  return texto(`Cliente gravado com sucesso! ${cliente.codigo}`);
});

rota('PUT', /^\/api\/cliente$/, (_, corpo) => {
  const atual = bd.clientes.find(c => c.codigo === +corpo.codigo);
  if (!atual) return texto('Cliente não encontrado!');
  Object.assign(atual, {
    nome: corpo.nome,
    telefone: corpo.telefone ?? null,
    documento: corpo.documento ?? null,
    logradouro: corpo.logradouro ?? null,
    email: corpo.email,
    senha: naoVazio(corpo.senha) ? corpo.senha : atual.senha,
  });
  return texto(`Cliente alterado com sucesso! ${atual.codigo}`);
});

rota('DELETE', /^\/api\/cliente\/(\d+)$/, ([id]) => {
  const i = bd.clientes.findIndex(c => c.codigo === +id);
  if (i < 0) return texto('Cliente não encontrado!');
  bd.clientes.splice(i, 1);
  return texto('Cliente removido com sucesso!');
});

rota('POST', /^\/api\/cliente\/login$/, (_, corpo) =>
  json(clienteJson(bd.clientes.find(
    c => c.ativo === 1 && c.email === corpo.email && c.senha === corpo.senha))));

rota('PATCH', /^\/api\/cliente\/resetarSenha$/, (_, corpo) => {
  const alvos = bd.clientes.filter(c => c.email === corpo.email);
  if (alvos.length === 0) regra('Não encontramos um cadastro com este e-mail.');
  alvos.forEach(c => { c.senha = 'Senha1234'; c.ativo = 1; });
  return texto('Sua senha foi redefinida para Senha1234.');
});

// Atenção: o campo "documento" carrega a SENHA ATUAL (igual ao backend).
rota('PATCH', /^\/api\/cliente\/alterarSenha$/, (_, corpo) => {
  const alvos = bd.clientes.filter(c => c.email === corpo.email && c.senha === corpo.documento);
  if (alvos.length === 0) regra('E-mail ou senha atual incorretos.');
  alvos.forEach(c => { c.senha = corpo.senha; c.ativo = 1; });
  return texto('Sua senha foi alterada!');
});

// -- Produto ------------------------------------------------------
rota('GET', /^\/api\/produtos$/, () =>
  json([...bd.produtos].sort((a, b) => a.codigo - b.codigo).map(produtoJson)));

rota('GET', /^\/api\/produto\/vitrine$/, () =>
  json(bd.produtos.filter(p => p.destaque > 0)
    .sort((a, b) => a.destaque - b.destaque).map(produtoJson)));

rota('GET', /^\/api\/produto\/busca\/(.+)$/, ([termo]) => {
  const alvo = normalizar(decodeURIComponent(termo));
  return json(bd.produtos
    .filter(p => normalizar(`${p.nome} ${p.descritivo} ${p.keywords}`).includes(alvo))
    .sort((a, b) => a.codigo - b.codigo)
    .map(produtoJson));
});

rota('GET', /^\/api\/produto\/(\d+)$/, ([id]) =>
  json(produtoJson(bd.produtos.find(p => p.codigo === +id))));

rota('POST', /^\/api\/produto$/, (_, corpo) => {
  const produto = {
    codigo: ++bd.seq.produto,
    nome: corpo.nome ?? corpo.descricao ?? null,
    descritivo: corpo.descritivo ?? null,
    keywords: corpo.keywords ?? null,
    valor: corpo.valor ?? 0,
    valorPromo: corpo.valorPromo ?? 0,
    quantidade: corpo.quantidade ?? 0,
    destaque: corpo.destaque ?? 0,
  };
  bd.produtos.push(produto);
  return texto(`Produto gravado com sucesso! ${produto.codigo}`);
});

rota('PUT', /^\/api\/produto$/, (_, corpo) => {
  const atual = bd.produtos.find(p => p.codigo === +corpo.codigo);
  if (!atual) return texto('Produto não encontrado!');
  Object.assign(atual, {
    nome: corpo.nome ?? corpo.descricao ?? atual.nome,
    descritivo: corpo.descritivo ?? null,
    keywords: corpo.keywords ?? null,
    valor: corpo.valor ?? 0,
    valorPromo: corpo.valorPromo ?? 0,
    quantidade: corpo.quantidade ?? 0,
    destaque: corpo.destaque ?? 0,
  });
  return texto(`Produto alterado com sucesso! ${atual.codigo}`);
});

rota('DELETE', /^\/api\/produto\/(\d+)$/, ([id]) => {
  const i = bd.produtos.findIndex(p => p.codigo === +id);
  if (i < 0) return texto('Produto não encontrado!');
  bd.produtos.splice(i, 1);
  return texto('Produto removido com sucesso!');
});

// -- Pedido -------------------------------------------------------
rota('POST', /^\/api\/pedido\/finalizar$/, (_, req) => {
  if (!bd.clientes.some(c => c.codigo === +req.codigoCliente)) {
    regra('Cliente não encontrado. Faça login para finalizar o pedido.');
  }
  if (!req.itens?.length) regra('A cesta está vazia.');

  const quantidades = new Map();
  for (const i of req.itens) {
    if (!(i.quantidade > 0)) regra(`Quantidade inválida para o produto ${i.codigoProduto}.`);
    quantidades.set(i.codigoProduto, (quantidades.get(i.codigoProduto) ?? 0) + i.quantidade);
  }

  // 1ª passada: valida tudo. Equivale ao @Transactional do backend — se um item
  // falhar, nada é gravado e nenhum estoque é baixado.
  const itens = [];
  let total = 0;
  for (const [codigoProduto, qtd] of quantidades) {
    const produto = bd.produtos.find(p => p.codigo === +codigoProduto);
    if (!produto) regra(`O produto ${codigoProduto} não existe mais.`);
    if (qtd > produto.quantidade) {
      const disponivel = produto.quantidade > 0
        ? `${produto.quantidade} unidade(s) disponível(is)` : 'esgotado';
      regra(`Estoque insuficiente para "${produto.nome}": ${disponivel}.`);
    }
    const unitario = precoAtual(produto);
    total += unitario * qtd;
    itens.push({ codigoProduto: +codigoProduto, quantidade: qtd, valor: unitario });
  }
  // 2ª passada: aplica (nenhuma validação pode falhar daqui para frente).
  for (const [codigoProduto, qtd] of quantidades) {
    bd.produtos.find(p => p.codigo === +codigoProduto).quantidade -= qtd;
  }

  const pedido = {
    codigoPedido: ++bd.seq.pedido,
    codigoCliente: +req.codigoCliente,
    entrega: req.entrega ?? null,
    obs: req.obs ?? null,
    valorTotal: duasCasas(total),
    dataPedido: hoje(),
  };
  bd.pedidos.push(pedido);
  itens.forEach(i => bd.itensPedido.push({
    codigoItemPedido: ++bd.seq.item, codigoPedido: pedido.codigoPedido, ...i,
  }));
  return json(pedidoComItens(pedido));
});

rota('GET', /^\/api\/pedido\/(\d+)\/detalhe$/, ([id]) => {
  const pedido = bd.pedidos.find(p => p.codigoPedido === +id);
  if (!pedido) regra('Pedido não encontrado.');
  return json(pedidoComItens(pedido));
});

rota('GET', /^\/api\/pedidos\/cliente\/(\d+)$/, ([id]) =>
  json(bd.pedidos.filter(p => p.codigoCliente === +id)
    .sort((a, b) => b.codigoPedido - a.codigoPedido).map(pedidoComItens)));

rota('GET', /^\/api\/pedido\/(\d+)$/, ([id]) =>
  json(pedidoJson(bd.pedidos.find(p => p.codigoPedido === +id))));

rota('POST', /^\/api\/pedido$/, (_, corpo) => {
  const pedido = {
    codigoPedido: ++bd.seq.pedido,
    codigoCliente: +corpo.codigoCliente || 0,
    valorTotal: corpo.valorTotal ?? 0,
    entrega: corpo.entrega ?? null,
    obs: corpo.obs ?? null,
    dataPedido: corpo.dataPedido ?? null,
  };
  bd.pedidos.push(pedido);
  return texto(`Pedido gravado com sucesso! ${pedido.codigoPedido}`);
});

rota('PUT', /^\/api\/pedido$/, (_, corpo) => {
  const atual = bd.pedidos.find(p => p.codigoPedido === +corpo.codigoPedido);
  if (!atual) return texto('Pedido não encontrado!');
  Object.assign(atual, {
    codigoCliente: +corpo.codigoCliente || 0,
    valorTotal: corpo.valorTotal ?? 0,
    entrega: corpo.entrega ?? null,
    obs: corpo.obs ?? null,
    dataPedido: corpo.dataPedido ?? null,
  });
  return texto(`Pedido alterado com sucesso! ${atual.codigoPedido}`);
});

rota('DELETE', /^\/api\/pedido\/(\d+)$/, ([id]) => {
  const i = bd.pedidos.findIndex(p => p.codigoPedido === +id);
  if (i < 0) return texto('Pedido não encontrado!');
  bd.pedidos.splice(i, 1);
  bd.itensPedido = bd.itensPedido.filter(it => it.codigoPedido !== +id); // não deixa item órfão
  return texto('Pedido removido com sucesso!');
});

// Só no dublê: devolve o banco ao estado inicial (usado pelos testes).
rota('POST', /^\/__teste\/reiniciar$/, () => {
  bd.clientes = []; bd.pedidos = []; bd.itensPedido = [];
  bd.seq = { produto: 0, cliente: 0, pedido: 0, item: 0 };
  semear();
  return texto('ok');
});

// ---------------------------------------------------------------- servidor
const texto = corpo => ({ status: 200, tipo: 'text/plain;charset=UTF-8', corpo });
const json = corpo => ({ status: 200, tipo: 'application/json', corpo: JSON.stringify(corpo) });

const servidor = createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const caminho = url.pathname;
  const origem = req.headers.origin;

  const cabecalhos = { 'Cache-Control': 'no-store' };
  if (origem && (ORIGENS.includes('*') || ORIGENS.includes(origem))) {
    cabecalhos['Access-Control-Allow-Origin'] = origem;
    cabecalhos['Vary'] = 'Origin';
  }

  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      ...cabecalhos,
      'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': req.headers['access-control-request-headers'] ?? '*',
      'Access-Control-Max-Age': '1800',
    });
    return res.end();
  }

  let bruto = '';
  req.on('data', p => (bruto += p));
  req.on('end', () => {
    const achada = rotas.find(r => r.metodo === req.method && r.padrao.test(caminho));
    if (!achada) {
      res.writeHead(404, { ...cabecalhos, 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ status: 404, error: 'Not Found', path: caminho }));
    }
    const grupos = caminho.match(achada.padrao).slice(1);
    let corpo = {};
    if (bruto) {
      try {
        corpo = JSON.parse(bruto);
      } catch {
        res.writeHead(400, { ...cabecalhos, 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ status: 400, error: 'Bad Request', message: 'JSON inválido' }));
      }
    }
    try {
      const r = achada.acao(grupos, corpo);
      res.writeHead(r.status, { ...cabecalhos, 'Content-Type': r.tipo });
      res.end(r.corpo);
      if (!SILENCIOSO) console.log(`${req.method} ${caminho} -> ${r.status}`);
    } catch (e) {
      if (e instanceof RegraNegocio) {
        res.writeHead(400, { ...cabecalhos, 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ mensagem: e.message }));
        if (!SILENCIOSO) console.log(`${req.method} ${caminho} -> 400 ${e.message}`);
      } else {
        res.writeHead(500, { ...cabecalhos, 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 500, error: 'Internal Server Error', message: String(e) }));
        console.error(e);
      }
    }
  });
});

servidor.listen(PORTA, () => {
  if (!SILENCIOSO) {
    console.log(`Dublê da API (apenas teste) em http://localhost:${PORTA} · ${bd.produtos.length} discos no catálogo`);
  }
});
