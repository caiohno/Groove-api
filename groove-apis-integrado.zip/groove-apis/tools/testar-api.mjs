/**
 * Testes de contrato da API da Lojinha — cobre TODOS os endpoints.
 *
 *   node tools/testar-api.mjs                       # http://localhost:8081
 *   node tools/testar-api.mjs --base http://host:porta
 *
 * Não precisa de Newman nem de nenhuma dependência: só Node 18+.
 * Cria os próprios dados (cliente/produto/pedido de teste) e apaga tudo no fim,
 * então pode rodar contra o backend real sem sujar o catálogo.
 */
const args = process.argv.slice(2);
const BASE = (args[args.indexOf('--base') + 1] ?? 'http://localhost:8081').replace(/\/$/, '');
const marca = Date.now();

let ok = 0;
const falhas = [];
const criados = { clientes: [], produtos: [], pedidos: [] };

function conferir(nome, condicao, detalhe = '') {
  if (condicao) {
    ok++;
    console.log(`  \x1b[32m✓\x1b[0m ${nome}`);
  } else {
    falhas.push({ nome, detalhe });
    console.log(`  \x1b[31m✗\x1b[0m ${nome}${detalhe ? ` — ${detalhe}` : ''}`);
  }
}

async function chamar(metodo, caminho, corpo) {
  const r = await fetch(BASE + caminho, {
    method: metodo,
    headers: corpo === undefined ? {} : { 'Content-Type': 'application/json' },
    body: corpo === undefined ? undefined : JSON.stringify(corpo),
  });
  const bruto = await r.text();
  let dados = bruto;
  try { dados = JSON.parse(bruto); } catch { /* resposta em texto puro */ }
  return { status: r.status, dados, texto: bruto, tipo: r.headers.get('content-type') ?? '' };
}

const codigoDaMensagem = t => Number(String(t).match(/(\d+)\s*$/)?.[1] ?? 0);
const grupo = t => console.log(`\n\x1b[1m${t}\x1b[0m`);

// ---------------------------------------------------------------- Produto (leitura)
async function produtoLeitura() {
  grupo('Produto · leitura');

  const todos = await chamar('GET', '/api/produtos');
  conferir('GET /api/produtos responde 200', todos.status === 200, `status ${todos.status}`);
  conferir('GET /api/produtos devolve uma lista não vazia',
    Array.isArray(todos.dados) && todos.dados.length > 0);
  const primeiro = Array.isArray(todos.dados) ? todos.dados[0] : {};
  conferir('o produto traz codigo, nome, valor, quantidade',
    ['codigo', 'nome', 'valor', 'quantidade'].every(c => c in primeiro),
    `campos: ${Object.keys(primeiro).join(',')}`);
  conferir('a lista vem ordenada por codigo',
    Array.isArray(todos.dados) &&
      todos.dados.every((p, i, a) => i === 0 || a[i - 1].codigo <= p.codigo));

  const catalogo = Array.isArray(todos.dados) ? todos.dados : [];
  const codigos = catalogo.map(p => p.codigo);
  const de1a20 = Array.from({ length: 20 }, (_, i) => i + 1).every(n => codigos.includes(n));
  conferir('o catálogo tem os códigos 1..20 (mesmos números das capas e dos áudios)',
    de1a20, `códigos encontrados: ${codigos.slice(0, 25).join(',')}`);

  const um = await chamar('GET', '/api/produto/1');
  conferir('GET /api/produto/1 devolve o produto 1', um.status === 200 && um.dados?.codigo === 1);
  conferir('o produto responde também em "descricao" (apelido de "nome")',
    um.dados?.descricao === um.dados?.nome);

  const sumido = await chamar('GET', '/api/produto/99999');
  conferir('produto inexistente devolve 200 com codigo 0 (contrato da API)',
    sumido.status === 200 && sumido.dados?.codigo === 0, `status ${sumido.status}`);

  const vitrine = await chamar('GET', '/api/produto/vitrine');
  conferir('GET /api/produto/vitrine responde 200', vitrine.status === 200);
  conferir('a vitrine traz só produtos em destaque',
    Array.isArray(vitrine.dados) && vitrine.dados.length > 0 &&
      vitrine.dados.every(p => p.destaque > 0));

  const busca = await chamar('GET', '/api/produto/busca/vinil');
  conferir('GET /api/produto/busca/vinil encontra discos',
    busca.status === 200 && Array.isArray(busca.dados) && busca.dados.length > 0);

  const semAcento = await chamar('GET', '/api/produto/busca/LEGIAO');
  conferir('a busca ignora acento e maiúscula (LEGIAO acha "Legião")',
    Array.isArray(semAcento.dados) && semAcento.dados.some(p => /Legi/i.test(p.nome ?? '')),
    JSON.stringify(semAcento.dados).slice(0, 120));

  const nada = await chamar('GET', '/api/produto/busca/zzzznaoexiste');
  conferir('busca sem resultado devolve lista vazia',
    nada.status === 200 && Array.isArray(nada.dados) && nada.dados.length === 0);
}

// ---------------------------------------------------------------- Produto (escrita)
async function produtoEscrita() {
  grupo('Produto · gravação, alteração e exclusão');

  const novo = {
    codigo: 987654, // deve ser ignorado pelo POST
    nome: `[teste ${marca}] Disco de Teste - Groove`,
    descritivo: 'Produto criado pelo teste automatizado.',
    keywords: 'teste, automatizado',
    valor: 100, valorPromo: 80, quantidade: 5, destaque: 0,
  };
  const gravado = await chamar('POST', '/api/produto', novo);
  const codigo = codigoDaMensagem(gravado.dados);
  if (codigo) criados.produtos.push(codigo);
  conferir('POST /api/produto responde "Produto gravado com sucesso! N"',
    gravado.status === 200 && /gravado com sucesso/i.test(gravado.texto) && codigo > 0,
    gravado.texto.slice(0, 120));
  conferir('o POST ignora o codigo enviado e gera um novo',
    codigo > 0 && codigo !== 987654, `codigo gerado: ${codigo}`);

  const lido = await chamar('GET', `/api/produto/${codigo}`);
  conferir('o produto gravado pode ser lido com os mesmos dados',
    lido.dados?.nome === novo.nome && lido.dados?.valor === 100 &&
      lido.dados?.valorPromo === 80 && lido.dados?.quantidade === 5);

  const alterado = await chamar('PUT', '/api/produto',
    { ...novo, codigo, nome: `[teste ${marca}] Disco Alterado`, valor: 120, valorPromo: 0, quantidade: 7 });
  conferir('PUT /api/produto altera o produto',
    alterado.status === 200 && /alterado com sucesso/i.test(alterado.texto), alterado.texto.slice(0, 120));
  const relido = await chamar('GET', `/api/produto/${codigo}`);
  conferir('a alteração foi gravada',
    relido.dados?.nome?.includes('Alterado') && relido.dados?.valor === 120 && relido.dados?.quantidade === 7);

  const inexistente = await chamar('PUT', '/api/produto', { ...novo, codigo: 99999 });
  conferir('PUT com codigo inexistente avisa "Produto não encontrado!"',
    /não encontrado/i.test(inexistente.texto), inexistente.texto.slice(0, 120));

  const apagado = await chamar('DELETE', `/api/produto/${codigo}`);
  conferir('DELETE /api/produto/{codigo} remove o produto',
    apagado.status === 200 && /removido com sucesso/i.test(apagado.texto), apagado.texto.slice(0, 120));
  const depois = await chamar('GET', `/api/produto/${codigo}`);
  conferir('o produto removido não é mais encontrado', depois.dados?.codigo === 0);
  criados.produtos = criados.produtos.filter(c => c !== codigo);
}

// ---------------------------------------------------------------- Cliente
async function cliente() {
  grupo('Cliente · cadastro, login e senha');

  const email = `teste.${marca}@groove.example`;
  const base = {
    nome: 'Cliente de Teste', email, senha: 'Senha@123',
    documento: '12345678901', telefone: '99999-9999', logradouro: 'Rua de Teste, 1',
  };

  const gravado = await chamar('POST', '/api/cliente', { ...base, codigo: 555 });
  const codigo = codigoDaMensagem(gravado.dados);
  if (codigo) criados.clientes.push(codigo);
  conferir('POST /api/cliente responde "Cliente gravado com sucesso! N"',
    gravado.status === 200 && codigo > 0, gravado.texto.slice(0, 140));

  const repetido = await chamar('POST', '/api/cliente', base);
  conferir('e-mail repetido devolve 400 com {"mensagem"}',
    repetido.status === 400 && typeof repetido.dados?.mensagem === 'string',
    `status ${repetido.status} ${repetido.texto.slice(0, 100)}`);

  const incompleto = await chamar('POST', '/api/cliente', { nome: '', email: '', senha: '' });
  conferir('cadastro sem nome/e-mail/senha devolve 400',
    incompleto.status === 400, `status ${incompleto.status}`);

  const lido = await chamar('GET', `/api/cliente/${codigo}`);
  conferir('GET /api/cliente/{codigo} devolve os dados',
    lido.status === 200 && lido.dados?.codigo === codigo && lido.dados?.email === email);
  conferir('a resposta NUNCA traz a senha',
    lido.dados && !('senha' in lido.dados), JSON.stringify(lido.dados).slice(0, 120));

  const sumido = await chamar('GET', '/api/cliente/999999');
  conferir('cliente inexistente devolve 200 com codigo 0',
    sumido.status === 200 && sumido.dados?.codigo === 0);

  const login = await chamar('POST', '/api/cliente/login', { email, senha: 'Senha@123' });
  conferir('POST /api/cliente/login com a senha certa devolve o cliente',
    login.status === 200 && login.dados?.codigo === codigo);
  conferir('o login também não devolve a senha', login.dados && !('senha' in login.dados));

  const errado = await chamar('POST', '/api/cliente/login', { email, senha: 'errada' });
  conferir('login com senha errada devolve codigo 0 (não 401)',
    errado.status === 200 && (errado.dados?.codigo ?? 0) === 0);

  const alterado = await chamar('PUT', '/api/cliente',
    { ...base, codigo, nome: 'Cliente Alterado', telefone: '88888-8888', senha: '' });
  conferir('PUT /api/cliente altera os dados',
    alterado.status === 200 && /alterado com sucesso/i.test(alterado.texto), alterado.texto.slice(0, 120));
  const relido = await chamar('GET', `/api/cliente/${codigo}`);
  conferir('a alteração foi gravada',
    relido.dados?.nome === 'Cliente Alterado' && relido.dados?.telefone === '88888-8888');
  const aindaEntra = await chamar('POST', '/api/cliente/login', { email, senha: 'Senha@123' });
  conferir('PUT com senha vazia mantém a senha anterior',
    aindaEntra.dados?.codigo === codigo);

  const semCliente = await chamar('PUT', '/api/cliente', { ...base, codigo: 999999 });
  conferir('PUT de cliente inexistente avisa "Cliente não encontrado!"',
    /não encontrado/i.test(semCliente.texto), semCliente.texto.slice(0, 120));

  // alterarSenha: o campo "documento" carrega a SENHA ATUAL (contrato do backend)
  const trocou = await chamar('PATCH', '/api/cliente/alterarSenha',
    { email, documento: 'Senha@123', senha: 'Nova@1234' });
  conferir('PATCH /api/cliente/alterarSenha troca a senha',
    trocou.status === 200 && /alterada/i.test(trocou.texto), trocou.texto.slice(0, 120));
  const comNova = await chamar('POST', '/api/cliente/login', { email, senha: 'Nova@1234' });
  conferir('o login passa a aceitar a senha nova', comNova.dados?.codigo === codigo);

  const senhaAtualErrada = await chamar('PATCH', '/api/cliente/alterarSenha',
    { email, documento: 'nao-e-a-senha', senha: 'Outra@1234' });
  conferir('alterarSenha com a senha atual errada devolve 400',
    senhaAtualErrada.status === 400, `status ${senhaAtualErrada.status}`);

  const reset = await chamar('PATCH', '/api/cliente/resetarSenha', { email });
  conferir('PATCH /api/cliente/resetarSenha responde 200',
    reset.status === 200, reset.texto.slice(0, 120));
  const comTemp = await chamar('POST', '/api/cliente/login', { email, senha: 'Senha1234' });
  conferir('a senha temporária entra no login e a conta continua ativa',
    comTemp.dados?.codigo === codigo);

  const semEmail = await chamar('PATCH', '/api/cliente/resetarSenha',
    { email: `nao.existe.${marca}@groove.example` });
  conferir('resetarSenha de e-mail inexistente devolve 400',
    semEmail.status === 400, `status ${semEmail.status}`);

  return codigo;
}

// ---------------------------------------------------------------- Pedido
async function pedido(codigoCliente) {
  grupo('Pedido · compra, estoque, histórico e CRUD');

  // dois produtos de teste: um com estoque e um esgotado
  const fazerProduto = async (nome, quantidade, valor, valorPromo) => {
    const r = await chamar('POST', '/api/produto',
      { nome: `[teste ${marca}] ${nome}`, descritivo: 'teste', keywords: 'teste', valor, valorPromo, quantidade, destaque: 0 });
    const c = codigoDaMensagem(r.dados);
    criados.produtos.push(c);
    return c;
  };
  const comEstoque = await fazerProduto('Com Estoque', 10, 100, 80);
  const esgotado = await fazerProduto('Esgotado', 0, 50, 0);

  const semCliente = await chamar('POST', '/api/pedido/finalizar',
    { codigoCliente: 999999, itens: [{ codigoProduto: comEstoque, quantidade: 1 }] });
  conferir('finalizar com cliente inexistente devolve 400',
    semCliente.status === 400 && !!semCliente.dados?.mensagem, `status ${semCliente.status}`);

  const vazio = await chamar('POST', '/api/pedido/finalizar', { codigoCliente, itens: [] });
  conferir('finalizar com a cesta vazia devolve 400', vazio.status === 400);

  const qtdInvalida = await chamar('POST', '/api/pedido/finalizar',
    { codigoCliente, itens: [{ codigoProduto: comEstoque, quantidade: 0 }] });
  conferir('finalizar com quantidade 0 devolve 400', qtdInvalida.status === 400);

  const produtoSumido = await chamar('POST', '/api/pedido/finalizar',
    { codigoCliente, itens: [{ codigoProduto: 999999, quantidade: 1 }] });
  conferir('finalizar com produto inexistente devolve 400', produtoSumido.status === 400);

  const acimaDoEstoque = await chamar('POST', '/api/pedido/finalizar',
    { codigoCliente, itens: [{ codigoProduto: comEstoque, quantidade: 999 }] });
  conferir('finalizar acima do estoque devolve 400 explicando o estoque',
    acimaDoEstoque.status === 400 && /estoque/i.test(acimaDoEstoque.dados?.mensagem ?? ''),
    String(acimaDoEstoque.dados?.mensagem).slice(0, 110));

  // transação: um item válido + um sem estoque não pode gravar nada
  const antesDoRollback = (await chamar('GET', `/api/produto/${comEstoque}`)).dados.quantidade;
  const misto = await chamar('POST', '/api/pedido/finalizar', {
    codigoCliente,
    itens: [{ codigoProduto: comEstoque, quantidade: 1 }, { codigoProduto: esgotado, quantidade: 1 }],
  });
  const depoisDoRollback = (await chamar('GET', `/api/produto/${comEstoque}`)).dados.quantidade;
  conferir('pedido com um item sem estoque falha inteiro (400)', misto.status === 400);
  conferir('e não baixa o estoque do item que estava ok (transação)',
    antesDoRollback === depoisDoRollback, `antes ${antesDoRollback}, depois ${depoisDoRollback}`);

  // compra válida: o preço é o do servidor (valorPromo = 80), não o enviado pelo cliente
  const estoqueAntes = depoisDoRollback;
  const compra = await chamar('POST', '/api/pedido/finalizar', {
    codigoCliente, entrega: 'Entrega padrão', obs: 'pedido de teste',
    itens: [{ codigoProduto: comEstoque, quantidade: 2, valorUnitario: 1 }],
  });
  const codigoPedido = compra.dados?.codigoPedido;
  if (codigoPedido) criados.pedidos.push(codigoPedido);
  conferir('POST /api/pedido/finalizar responde 200 com o pedido',
    compra.status === 200 && codigoPedido > 0, `status ${compra.status} ${compra.texto.slice(0, 110)}`);
  conferir('o pedido traz os itens com nome do produto e valores',
    compra.dados?.itens?.length === 1 && compra.dados.itens[0].nomeProduto?.includes('Com Estoque') &&
      compra.dados.itens[0].quantidade === 2);
  conferir('o preço cobrado é o do banco (promoção 80), não o enviado pelo cliente',
    compra.dados?.itens?.[0]?.valorUnitario === 80 && compra.dados?.valorTotal === 160,
    `unitário ${compra.dados?.itens?.[0]?.valorUnitario}, total ${compra.dados?.valorTotal}`);
  conferir('a data do pedido vem no formato yyyy-MM-dd',
    /^\d{4}-\d{2}-\d{2}$/.test(String(compra.dados?.dataPedido ?? '')),
    String(compra.dados?.dataPedido));

  const estoqueDepois = (await chamar('GET', `/api/produto/${comEstoque}`)).dados.quantidade;
  conferir('o estoque baixou exatamente a quantidade comprada',
    estoqueDepois === estoqueAntes - 2, `${estoqueAntes} -> ${estoqueDepois}`);

  // linhas repetidas do mesmo produto somam
  const repetido = await chamar('POST', '/api/pedido/finalizar', {
    codigoCliente,
    itens: [{ codigoProduto: comEstoque, quantidade: 1 }, { codigoProduto: comEstoque, quantidade: 2 }],
  });
  if (repetido.dados?.codigoPedido) criados.pedidos.push(repetido.dados.codigoPedido);
  conferir('linhas repetidas do mesmo produto viram um item só, somando a quantidade',
    repetido.dados?.itens?.length === 1 && repetido.dados.itens[0].quantidade === 3,
    JSON.stringify(repetido.dados?.itens).slice(0, 110));

  const detalhe = await chamar('GET', `/api/pedido/${codigoPedido}/detalhe`);
  conferir('GET /api/pedido/{codigo}/detalhe devolve o pedido com itens',
    detalhe.status === 200 && detalhe.dados?.codigoPedido === codigoPedido &&
      detalhe.dados?.itens?.length === 1);
  conferir('o detalhe repete entrega e obs enviados na compra',
    detalhe.dados?.entrega === 'Entrega padrão' && detalhe.dados?.obs === 'pedido de teste');

  const detalheSumido = await chamar('GET', '/api/pedido/999999/detalhe');
  conferir('detalhe de pedido inexistente devolve 400 com mensagem',
    detalheSumido.status === 400 && !!detalheSumido.dados?.mensagem, `status ${detalheSumido.status}`);

  const historico = await chamar('GET', `/api/pedidos/cliente/${codigoCliente}`);
  conferir('GET /api/pedidos/cliente/{codigo} lista os pedidos do cliente',
    historico.status === 200 && Array.isArray(historico.dados) && historico.dados.length >= 2);
  conferir('o histórico vem do mais novo para o mais antigo',
    Array.isArray(historico.dados) &&
      historico.dados.every((p, i, a) => i === 0 || a[i - 1].codigoPedido > p.codigoPedido),
    JSON.stringify(historico.dados?.map(p => p.codigoPedido)));
  conferir('cada pedido do histórico já vem com os itens',
    historico.dados?.[0]?.itens?.length > 0);

  const cru = await chamar('GET', `/api/pedido/${codigoPedido}`);
  conferir('GET /api/pedido/{codigo} devolve o pedido (sem itens)',
    cru.status === 200 && cru.dados?.codigoPedido === codigoPedido);
  conferir('a data do pedido também sai como yyyy-MM-dd em /api/pedido/{codigo}',
    /^\d{4}-\d{2}-\d{2}$/.test(String(cru.dados?.dataPedido ?? '')), String(cru.dados?.dataPedido));

  const novoCru = await chamar('POST', '/api/pedido',
    { codigoCliente, valorTotal: 10, entrega: 'teste', obs: 'crud cru', dataPedido: '2026-01-15' });
  const codigoCru = codigoDaMensagem(novoCru.dados);
  if (codigoCru) criados.pedidos.push(codigoCru);
  conferir('POST /api/pedido grava um pedido avulso',
    novoCru.status === 200 && codigoCru > 0, novoCru.texto.slice(0, 120));

  const alteradoCru = await chamar('PUT', '/api/pedido',
    { codigoPedido: codigoCru, codigoCliente, valorTotal: 22, entrega: 'alterada', obs: 'ok', dataPedido: '2026-01-16' });
  conferir('PUT /api/pedido altera o pedido',
    alteradoCru.status === 200 && /alterado com sucesso/i.test(alteradoCru.texto),
    alteradoCru.texto.slice(0, 120));
  const releituraCru = await chamar('GET', `/api/pedido/${codigoCru}`);
  conferir('a alteração do pedido foi gravada', releituraCru.dados?.valorTotal === 22);

  const putSumido = await chamar('PUT', '/api/pedido', { codigoPedido: 999999, codigoCliente, valorTotal: 1 });
  conferir('PUT de pedido inexistente avisa "Pedido não encontrado!"',
    /não encontrado/i.test(putSumido.texto), putSumido.texto.slice(0, 120));

  const apagadoCru = await chamar('DELETE', `/api/pedido/${codigoCru}`);
  conferir('DELETE /api/pedido/{codigo} remove o pedido',
    apagadoCru.status === 200 && /removido com sucesso/i.test(apagadoCru.texto),
    apagadoCru.texto.slice(0, 120));
  criados.pedidos = criados.pedidos.filter(c => c !== codigoCru);
  const apagadoDepois = await chamar('GET', `/api/pedido/${codigoCru}`);
  conferir('o pedido removido não é mais encontrado', (apagadoDepois.dados?.codigoPedido ?? 0) === 0);

  // DELETE do pedido não pode deixar item órfão no banco
  const comItens = criados.pedidos[0];
  await chamar('DELETE', `/api/pedido/${comItens}`);
  const detalheOrfao = await chamar('GET', `/api/pedido/${comItens}/detalhe`);
  conferir('apagar um pedido com itens não deixa o detalhe acessível',
    detalheOrfao.status === 400, `status ${detalheOrfao.status}`);
  criados.pedidos = criados.pedidos.filter(c => c !== comItens);
}

// ---------------------------------------------------------------- CORS
async function cors() {
  grupo('CORS · o frontend precisa poder chamar a API de outra origem');
  const r = await fetch(`${BASE}/api/produtos`, {
    method: 'OPTIONS',
    headers: {
      Origin: 'http://localhost:4200',
      'Access-Control-Request-Method': 'GET',
      'Access-Control-Request-Headers': 'content-type',
    },
  });
  const origem = r.headers.get('access-control-allow-origin');
  conferir('o preflight (OPTIONS) libera http://localhost:4200',
    r.status < 400 && (origem === 'http://localhost:4200' || origem === '*'),
    `status ${r.status}, allow-origin: ${origem}`);
}

// ---------------------------------------------------------------- limpeza
async function limpar() {
  grupo('Limpeza dos dados de teste');
  for (const c of criados.pedidos) await chamar('DELETE', `/api/pedido/${c}`);
  for (const c of criados.produtos) await chamar('DELETE', `/api/produto/${c}`);
  for (const c of criados.clientes) await chamar('DELETE', `/api/cliente/${c}`);
  const sobrou = await chamar('GET', '/api/produtos');
  const lixo = (Array.isArray(sobrou.dados) ? sobrou.dados : []).filter(p => p.nome?.includes('[teste '));
  conferir('nenhum produto de teste sobrou no catálogo', lixo.length === 0,
    lixo.map(p => p.codigo).join(','));
  for (const c of criados.clientes) {
    const r = await chamar('GET', `/api/cliente/${c}`);
    conferir(`cliente de teste ${c} foi removido`, (r.dados?.codigo ?? 0) === 0);
  }
}

// ---------------------------------------------------------------- execução
(async () => {
  console.log(`\nTestando a API em ${BASE}\n${'─'.repeat(50)}`);
  try {
    await chamar('GET', '/api/produtos');
  } catch (e) {
    console.error(`\n\x1b[31mNão consegui falar com ${BASE}\x1b[0m`);
    console.error('Suba o backend (cd backend && ./mvnw spring-boot:run) ou use --base.');
    process.exit(2);
  }
  try {
    await produtoLeitura();
    await produtoEscrita();
    const codigoCliente = await cliente();
    await pedido(codigoCliente);
    await cors();
  } finally {
    await limpar();
  }

  console.log(`\n${'─'.repeat(50)}`);
  if (falhas.length === 0) {
    console.log(`\x1b[32m${ok} verificações, nenhuma falha.\x1b[0m\n`);
  } else {
    console.log(`\x1b[31m${falhas.length} falha(s)\x1b[0m de ${ok + falhas.length} verificações:\n`);
    falhas.forEach(f => console.log(`  · ${f.nome}${f.detalhe ? `\n    ${f.detalhe}` : ''}`));
    console.log('');
  }
  process.exit(falhas.length === 0 ? 0 : 1);
})();
