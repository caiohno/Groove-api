package com.ads.lojinha.repository

import com.ads.lojinha.model.Cliente
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Transactional

@Repository
interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    @Query(value = 'select * from cliente where ativo=1 and email=:email and senha=:senha', nativeQuery = true)
    Optional<Cliente> fazerLogin(@Param('email') String email, @Param('senha') String senha)

    boolean existsByEmail(String email)

    // A conta continua ativa (ativo=1): o cliente entra com a senha temporária.
    @Modifying
    @Transactional
    @Query(value = 'update cliente set senha=:senhaTemp, ativo=1 where email=:email', nativeQuery = true)
    int resetarSenha(@Param('senhaTemp') String senhaTemp, @Param('email') String email)

    @Modifying
    @Transactional
    @Query(value = 'update cliente set senha=:novaSenha, ativo=1 where email=:email and senha=:antigaSenha', nativeQuery = true)
    int alterarSenha(@Param('novaSenha') String novaSenha,
                     @Param('antigaSenha') String antigaSenha,
                     @Param('email') String email)
}
