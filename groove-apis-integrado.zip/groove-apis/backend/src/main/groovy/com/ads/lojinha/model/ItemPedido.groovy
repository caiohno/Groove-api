package com.ads.lojinha.model

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
class ItemPedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int codigoItemPedido
    // Integer (aceita nulo) para o Hibernate conseguir adicionar a coluna na tabela já existente do SQLite.
    Integer codigoPedido
    int codigoProduto
    int quantidade
    /** Valor UNITÁRIO cobrado no momento da compra. */
    double valor
}
