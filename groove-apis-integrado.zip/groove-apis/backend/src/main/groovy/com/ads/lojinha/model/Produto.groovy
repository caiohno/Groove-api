package com.ads.lojinha.model

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
class Produto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int codigo
    String nome
    String descritivo
    String keywords
    double valor
    double valorPromo
    int quantidade
    int destaque

    /** Preço efetivo: promoção quando houver, senão o valor normal. */
    double precoAtual() {
        valorPromo > 0 ? valorPromo : valor
    }

    /**
     * Compatibilidade com clientes que usam "descricao" (apelido de "nome").
     * Não é coluna: o mapeamento do JPA é por campo.
     */
    String getDescricao() { nome }

    void setDescricao(String descricao) {
        if (descricao != null) {
            nome = descricao
        }
    }
}
