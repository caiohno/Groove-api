package com.ads.lojinha.service

/** Erro de regra de negócio: vira HTTP 400 com {"mensagem": "..."} */
class RegraNegocioException extends RuntimeException {
    RegraNegocioException(String mensagem) {
        super(mensagem)
    }
}
