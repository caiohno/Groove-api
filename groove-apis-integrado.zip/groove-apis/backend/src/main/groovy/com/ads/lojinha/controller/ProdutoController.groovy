package com.ads.lojinha.controller

import com.ads.lojinha.model.Produto
import com.ads.lojinha.repository.ProdutoRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*

import java.text.Normalizer

@RestController
class ProdutoController {

    @Autowired
    ProdutoRepository bd

    @GetMapping('/api/produto/{codigo}')
    Produto retornaProduto(@PathVariable('codigo') int id) {
        bd.findById(id).orElseGet { new Produto() }
    }

    @PostMapping('/api/produto')
    String gravar(@RequestBody Produto obj) {
        obj.codigo = 0   // POST sempre cria; para alterar use PUT
        bd.save(obj)
        "Produto gravado com sucesso! ${obj.codigo}"
    }

    @PutMapping('/api/produto')
    String alterar(@RequestBody Produto obj) {
        if (bd.existsById(obj.codigo)) {
            bd.save(obj)
            "Produto alterado com sucesso! ${obj.codigo}"
        } else {
            'Produto não encontrado!'
        }
    }

    @DeleteMapping('/api/produto/{codigo}')
    String apagar(@PathVariable('codigo') int id) {
        // deleteById é silencioso quando o código não existe: avisamos o cliente.
        if (!bd.existsById(id)) {
            return 'Produto não encontrado!'
        }
        bd.deleteById(id)
        'Produto removido com sucesso!'
    }

    @GetMapping('/api/produtos')
    List<Produto> listar() {
        bd.findAll().sort { it.codigo }
    }

    @GetMapping('/api/produto/vitrine')
    List<Produto> carregaVitrine() {
        bd.carregaVitrine()
    }

    /** Busca por nome, descrição ou palavras-chave, sem diferenciar maiúsculas nem acentos. */
    @GetMapping('/api/produto/busca/{termo}')
    List<Produto> fazerBusca(@PathVariable('termo') String termo) {
        String alvo = normalizar(termo)
        bd.findAll().findAll { Produto p ->
            normalizar("${p.nome} ${p.descritivo} ${p.keywords}".toString()).contains(alvo)
        }.sort { it.codigo }
    }

    private static String normalizar(String texto) {
        Normalizer.normalize(texto ?: '', Normalizer.Form.NFD)
                .replaceAll('\\p{InCombiningDiacriticalMarks}+', '')
                .toLowerCase()
    }
}
