package com.ads.lojinha.config

import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Configuration
import org.springframework.web.servlet.config.annotation.CorsRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer

/**
 * Libera o frontend (Angular) a chamar a API, já que ele roda em outra origem.
 * As origens vêm de lojinha.cors.allowed-origins (use "*" para liberar todas).
 */
@Configuration
class CorsConfig implements WebMvcConfigurer {

    @Value('${lojinha.cors.allowed-origins:*}')
    String allowedOrigins

    @Override
    void addCorsMappings(CorsRegistry registry) {
        registry.addMapping('/api/**')
                .allowedOriginPatterns(allowedOrigins.split(',')*.trim() as String[])
                .allowedMethods('GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS')
                .allowedHeaders('*')
    }
}
