package com.ads.lojinha.repository

import com.ads.lojinha.model.Pedido
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface PedidoRepository extends JpaRepository<Pedido, Integer> {
    List<Pedido> findByCodigoClienteOrderByCodigoPedidoDesc(int codigoCliente)
}
