package com.ads.lojinha.dto

import com.fasterxml.jackson.annotation.JsonIgnoreProperties

@JsonIgnoreProperties(ignoreUnknown = true)
class PedidoRequest {
    int codigoCliente
    String entrega
    String obs
    List<ItemRequest> itens = []

    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ItemRequest {
        int codigoProduto
        int quantidade
    }
}
