package com.ads.lojinha.model

import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int codigoPedido
    double valorTotal
    String entrega
    String obs
    // Sem isto o Jackson devolveria a data como número (epoch), diferente do
    // "yyyy-MM-dd" que /api/pedido/{codigo}/detalhe já usava.
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = 'yyyy-MM-dd')
    java.sql.Date dataPedido
    int codigoCliente
}
