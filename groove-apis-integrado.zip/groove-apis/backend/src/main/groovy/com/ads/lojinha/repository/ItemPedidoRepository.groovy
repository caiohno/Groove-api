package com.ads.lojinha.repository

import com.ads.lojinha.model.ItemPedido
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ItemPedidoRepository extends JpaRepository<ItemPedido, Integer> {
    List<ItemPedido> findByCodigoPedido(Integer codigoPedido)
}
