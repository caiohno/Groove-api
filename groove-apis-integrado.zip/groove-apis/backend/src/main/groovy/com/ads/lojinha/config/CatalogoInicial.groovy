package com.ads.lojinha.config

import com.ads.lojinha.model.Produto
import com.ads.lojinha.repository.ProdutoRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.ApplicationArguments
import org.springframework.boot.ApplicationRunner
import org.springframework.stereotype.Component

/**
 * Cadastra os 20 discos do catálogo Groove quando a tabela produto está vazia.
 * Como o código é gerado em ordem, os discos ficam com código 1..20, que são os
 * mesmos números das capas (N.png) e prévias de áudio (audio/N.mp3) do frontend.
 */
@Component
class CatalogoInicial implements ApplicationRunner {

    @Autowired
    ProdutoRepository bd

    @Override
    void run(ApplicationArguments args) {
        if (bd.count() > 0) {
            return
        }
        CATALOGO.each { Map dados -> bd.save(new Produto(dados)) }
    }

    static final List<Map> CATALOGO = [
            [nome: 'Wish You Were Here - Pink Floyd', descritivo: 'Uma obra de rock progressivo com longas construções instrumentais e clima contemplativo.', keywords: 'rock progressivo, rock clássico, Pink Floyd, anos 1970, vinil', valor: 159.9, valorPromo: 0, quantidade: 18, destaque: 1],
            [nome: 'Sgt. Pepper\'s Lonely Hearts Club Band - The Beatles', descritivo: 'Arranjos inventivos e psicodelia em um álbum marcante do rock britânico.', keywords: 'rock psicodélico, rock britânico, The Beatles, anos 1960, vinil', valor: 189.9, valorPromo: 0, quantidade: 12, destaque: 0],
            [nome: 'Bad - Michael Jackson', descritivo: 'Pop e R&B em canções dançantes, com produção marcante e vocais fortes.', keywords: 'pop, R&B, dance-pop, Michael Jackson, anos 1980, vinil', valor: 179.9, valorPromo: 149.9, quantidade: 0, destaque: 0],
            [nome: 'In Utero - Nirvana', descritivo: 'Grunge cru e alternativo, com guitarras intensas e dinâmica contrastante.', keywords: 'grunge, rock alternativo, Nirvana, anos 1990, vinil', valor: 169.9, valorPromo: 139.9, quantidade: 0, destaque: 0],
            [nome: 'Rumours - Fleetwood Mac', descritivo: 'Rock melódico, harmonias delicadas e emoções à flor da pele em cada lado.', keywords: 'rock pop soft rock, Fleetwood Mac, vinil', valor: 179.9, valorPromo: 149.9, quantidade: 15, destaque: 0],
            [nome: 'Kind of Blue - Miles Davis', descritivo: 'Jazz para desacelerar: melodias livres e o timbre marcante do trompete de Miles Davis.', keywords: 'jazz instrumental, Miles Davis, vinil', valor: 199.9, valorPromo: 169.9, quantidade: 10, destaque: 1],
            [nome: 'Purple Rain - Prince', descritivo: 'Guitarras, sintetizadores e soul na mistura eletrizante de Prince.', keywords: 'pop rock funk soul, Prince, vinil', valor: 189.9, valorPromo: 0, quantidade: 16, destaque: 0],
            [nome: 'A Night at the Opera - Queen', descritivo: 'Rock teatral, arranjos ousados e a voz inconfundível de Freddie Mercury.', keywords: 'rock clássico hard rock, Queen, vinil', valor: 189.9, valorPromo: 159.9, quantidade: 20, destaque: 0],
            [nome: 'The Miseducation of Lauryn Hill - Lauryn Hill', descritivo: 'Soul, R&B e hip-hop se encontram nas rimas e na voz envolvente de Lauryn Hill.', keywords: 'hip hop rap soul r&b, Lauryn Hill, vinil', valor: 219.9, valorPromo: 189.9, quantidade: 12, destaque: 1],
            [nome: 'Clube da Esquina - Milton Nascimento & Lô Borges', descritivo: 'A riqueza da música brasileira em melodias, harmonias e encontros que atravessam gerações.', keywords: 'mpb música brasileira brasil, Milton Nascimento & Lô Borges, vinil', valor: 179.9, valorPromo: 0, quantidade: 18, destaque: 0],
            [nome: 'Legião Urbana - Legião Urbana', descritivo: 'Guitarras e letras diretas na estreia que traduz a força do rock brasileiro.', keywords: 'rock nacional brasil punk, Legião Urbana, vinil', valor: 139.9, valorPromo: 119.9, quantidade: 22, destaque: 0],
            [nome: 'Raimundos - Raimundos', descritivo: 'Peso, velocidade e influências nordestinas na mistura irreverente dos Raimundos.', keywords: 'rock nacional punk hardcore brasil, Raimundos, vinil', valor: 149.9, valorPromo: 129.9, quantidade: 14, destaque: 0],
            [nome: 'Sobrevivendo no Inferno - Racionais MC\'s', descritivo: 'Narrativas contundentes e batidas marcantes em um disco essencial do rap brasileiro.', keywords: 'rap hip hop nacional brasil, Racionais MC\'s, vinil', valor: 199.9, valorPromo: 0, quantidade: 20, destaque: 0],
            [nome: 'Discovery - Daft Punk', descritivo: 'Batidas eletrônicas, disco e melodias luminosas para colocar a agulha e dançar.', keywords: 'eletrônica house disco dance, Daft Punk, vinil', valor: 219.9, valorPromo: 189.9, quantidade: 17, destaque: 0],
            [nome: 'Back in Black - AC/DC', descritivo: 'Riffs poderosos e hard rock sem rodeios para ouvir com o volume lá em cima.', keywords: 'rock hard rock, AC/DC, vinil', valor: 169.9, valorPromo: 139.9, quantidade: 25, destaque: 0],
            [nome: 'The Chronic - Dr. Dre', descritivo: 'Batidas de G-funk e rimas da Costa Oeste em um marco do hip-hop.', keywords: 'rap hip hop g-funk, Dr. Dre, vinil', valor: 199.9, valorPromo: 169.9, quantidade: 15, destaque: 0],
            [nome: 'Elvis Presley - Elvis Presley', descritivo: 'A energia do rock and roll e a voz de Elvis em seu álbum de estreia.', keywords: 'rock and roll rockabilly, Elvis Presley, vinil', valor: 139.9, valorPromo: 119.9, quantidade: 24, destaque: 0],
            [nome: 'Back to Black - Amy Winehouse', descritivo: 'Soul de inspiração retrô e a voz singular de Amy em canções cheias de sentimento.', keywords: 'soul jazz r&b, Amy Winehouse, vinil', valor: 179.9, valorPromo: 149.9, quantidade: 18, destaque: 1],
            [nome: 'Lemonade - Beyoncé', descritivo: 'R&B, pop e diferentes sonoridades em um álbum intenso sobre afeto e transformação.', keywords: 'pop r&b soul, Beyoncé, vinil', valor: 239.9, valorPromo: 199.9, quantidade: 10, destaque: 0],
            [nome: 'Spice - Spice Girls', descritivo: 'Pop contagiante e a energia das Spice Girls para cantar junto a cada faixa.', keywords: 'pop dance girl power, Spice Girls, vinil', valor: 169.9, valorPromo: 139.9, quantidade: 12, destaque: 0]
    ]
}
