package com.ads.lojinha.controller

import com.ads.lojinha.dto.PedidoRequest
import com.ads.lojinha.model.Pedido
import com.ads.lojinha.repository.PedidoRepository
import com.ads.lojinha.service.PedidoService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*

@RestController
class PedidoController {

    @Autowired PedidoRepository bd
    @Autowired PedidoService service

    /** Compra: grava pedido + itens e baixa o estoque. */
    @PostMapping('/api/pedido/finalizar')
    Map<String, Object> finalizar(@RequestBody PedidoRequest req) {
        service.finalizar(req)
    }

    /** Pedido completo (com itens). */
    @GetMapping('/api/pedido/{codigo}/detalhe')
    Map<String, Object> detalhe(@PathVariable('codigo') int id) {
        service.buscar(id)
    }

    /** Histórico de pedidos do cliente, do mais novo para o mais antigo. */
    @GetMapping('/api/pedidos/cliente/{codigoCliente}')
    List<Map<String, Object>> doCliente(@PathVariable('codigoCliente') int codigoCliente) {
        service.listarPorCliente(codigoCliente)
    }

    @GetMapping('/api/pedido/{codigo}')
    Pedido retorna(@PathVariable('codigo') int id) {
        bd.findById(id).orElseGet { new Pedido() }
    }

    @PostMapping('/api/pedido')
    String gravar(@RequestBody Pedido obj) {
        obj.codigoPedido = 0   // POST sempre cria um novo registro
        bd.save(obj)
        "Pedido gravado com sucesso! ${obj.codigoPedido}"
    }

    @PutMapping('/api/pedido')
    String alterar(@RequestBody Pedido obj) {
        if (bd.existsById(obj.codigoPedido)) {
            bd.save(obj)
            "Pedido alterado com sucesso! ${obj.codigoPedido}"
        } else {
            'Pedido não encontrado!'
        }
    }

    /** Remove o pedido e também os seus itens, para não deixar item órfão no banco. */
    @DeleteMapping('/api/pedido/{codigo}')
    String apagar(@PathVariable('codigo') int id) {
        if (!bd.existsById(id)) {
            return 'Pedido não encontrado!'
        }
        service.apagar(id)
        'Pedido removido com sucesso!'
    }
}
