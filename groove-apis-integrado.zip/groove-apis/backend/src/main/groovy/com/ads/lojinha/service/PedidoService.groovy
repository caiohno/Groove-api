package com.ads.lojinha.service

import com.ads.lojinha.dto.PedidoRequest
import com.ads.lojinha.model.ItemPedido
import com.ads.lojinha.model.Pedido
import com.ads.lojinha.model.Produto
import com.ads.lojinha.repository.ClienteRepository
import com.ads.lojinha.repository.ItemPedidoRepository
import com.ads.lojinha.repository.PedidoRepository
import com.ads.lojinha.repository.ProdutoRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
class PedidoService {

    @Autowired PedidoRepository pedidos
    @Autowired ItemPedidoRepository itensPedido
    @Autowired ProdutoRepository produtos
    @Autowired ClienteRepository clientes

    /**
     * Finaliza a compra: valida cliente e estoque, grava o pedido com os itens
     * usando os preços do banco (nunca os enviados pelo cliente) e baixa o estoque.
     * Tudo na mesma transação: se qualquer item falhar, nada é gravado.
     */
    @Transactional
    Map<String, Object> finalizar(PedidoRequest req) {
        if (!clientes.existsById(req.codigoCliente)) {
            throw new RegraNegocioException('Cliente não encontrado. Faça login para finalizar o pedido.')
        }
        if (!req.itens) {
            throw new RegraNegocioException('A cesta está vazia.')
        }

        // junta linhas repetidas do mesmo produto
        Map<Integer, Integer> quantidades = [:]
        req.itens.each { PedidoRequest.ItemRequest i ->
            if (i.quantidade <= 0) {
                throw new RegraNegocioException('Quantidade inválida para o produto ' + i.codigoProduto + '.')
            }
            quantidades[i.codigoProduto] = (quantidades[i.codigoProduto] ?: 0) + i.quantidade
        }

        List<ItemPedido> itens = []
        double total = 0
        quantidades.each { Integer codigoProduto, Integer qtd ->
            Produto produto = produtos.findById(codigoProduto).orElse(null)
            if (produto == null) {
                throw new RegraNegocioException('O produto ' + codigoProduto + ' não existe mais.')
            }
            if (qtd > produto.quantidade) {
                String disponivel = produto.quantidade > 0 ? "${produto.quantidade} unidade(s) disponível(is)" : 'esgotado'
                throw new RegraNegocioException("Estoque insuficiente para \"${produto.nome}\": ${disponivel}.".toString())
            }
            produto.quantidade = produto.quantidade - qtd
            produtos.save(produto)

            double unitario = produto.precoAtual()
            total += unitario * qtd
            itens << new ItemPedido(codigoProduto: codigoProduto, quantidade: qtd, valor: unitario)
        }

        Pedido pedido = pedidos.save(new Pedido(
                codigoCliente: req.codigoCliente,
                entrega: req.entrega,
                obs: req.obs,
                valorTotal: Math.round(total * 100) / 100d,
                dataPedido: new java.sql.Date(System.currentTimeMillis())))

        itens.each { ItemPedido item ->
            item.codigoPedido = pedido.codigoPedido
            itensPedido.save(item)
        }
        paraMapa(pedido)
    }

    /** Apaga o pedido junto com os seus itens (mesma transação). */
    @Transactional
    void apagar(int codigoPedido) {
        itensPedido.deleteAll(itensPedido.findByCodigoPedido(codigoPedido))
        pedidos.deleteById(codigoPedido)
    }

    Map<String, Object> buscar(int codigoPedido) {
        Pedido pedido = pedidos.findById(codigoPedido).orElse(null)
        if (pedido == null) {
            throw new RegraNegocioException('Pedido não encontrado.')
        }
        paraMapa(pedido)
    }

    List<Map<String, Object>> listarPorCliente(int codigoCliente) {
        pedidos.findByCodigoClienteOrderByCodigoPedidoDesc(codigoCliente).collect { paraMapa(it) }
    }

    /** Pedido + itens (com o nome do produto), no formato consumido pelo frontend. */
    private Map<String, Object> paraMapa(Pedido p) {
        List<Map<String, Object>> itens = itensPedido.findByCodigoPedido(p.codigoPedido).collect { ItemPedido i ->
            Produto produto = produtos.findById(i.codigoProduto).orElse(null)
            [
                    codigoProduto: i.codigoProduto,
                    nomeProduto  : produto?.nome ?: 'Produto removido',
                    quantidade   : i.quantidade,
                    valorUnitario: i.valor,
                    valorTotal   : Math.round(i.valor * i.quantidade * 100) / 100d
            ] as Map<String, Object>
        }
        [
                codigoPedido : p.codigoPedido,
                codigoCliente: p.codigoCliente,
                dataPedido   : p.dataPedido?.toString(),
                valorTotal   : p.valorTotal,
                entrega      : p.entrega,
                obs          : p.obs,
                itens        : itens
        ] as Map<String, Object>
    }
}
