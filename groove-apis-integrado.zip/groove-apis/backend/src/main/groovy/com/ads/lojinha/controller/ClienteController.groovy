package com.ads.lojinha.controller

import com.ads.lojinha.model.Cliente
import com.ads.lojinha.repository.ClienteRepository
import com.ads.lojinha.service.RegraNegocioException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*

@RestController
class ClienteController {

    @Autowired
    ClienteRepository bd

    @GetMapping('/api/cliente/{codigo}')
    Cliente retorna(@PathVariable('codigo') int id) {
        bd.findById(id).orElseGet { new Cliente() }
    }

    @PostMapping('/api/cliente')
    String gravar(@RequestBody Cliente obj) {
        if (!obj.nome?.trim() || !obj.email?.trim() || !obj.senha) {
            throw new RegraNegocioException('Informe nome, e-mail e senha.')
        }
        obj.email = obj.email.trim()
        if (bd.existsByEmail(obj.email)) {
            throw new RegraNegocioException('Já existe um cadastro com este e-mail.')
        }
        obj.codigo = 0        // POST sempre cria um novo cliente
        obj.ativo = 1         // conta nasce ativa: o login só aceita ativo=1
        bd.save(obj)
        "Cliente gravado com sucesso! ${obj.codigo}"
    }

    @PutMapping('/api/cliente')
    String alterar(@RequestBody Cliente obj) {
        Cliente atual = bd.findById(obj.codigo).orElse(null)
        if (atual == null) {
            return 'Cliente não encontrado!'
        }
        if (!obj.senha) {
            obj.senha = atual.senha   // senha em branco = manter a atual
        }
        obj.ativo = atual.ativo
        bd.save(obj)
        "Cliente alterado com sucesso! ${obj.codigo}"
    }

    @DeleteMapping('/api/cliente/{codigo}')
    String apagar(@PathVariable('codigo') int id) {
        // deleteById é silencioso quando o código não existe: avisamos o cliente.
        if (!bd.existsById(id)) {
            return 'Cliente não encontrado!'
        }
        bd.deleteById(id)
        'Cliente removido com sucesso!'
    }

    @PostMapping('/api/cliente/login')
    Cliente fazerLogin(@RequestBody Cliente obj) {
        bd.fazerLogin(obj.email, obj.senha).orElseGet { new Cliente() }
    }

    @PatchMapping('/api/cliente/resetarSenha')
    String resetarSenha(@RequestBody Cliente obj) {
        String senhaTemp = 'Senha1234'
        if (bd.resetarSenha(senhaTemp, obj.email) == 0) {
            throw new RegraNegocioException('Não encontramos um cadastro com este e-mail.')
        }
        // TODO enviar e-mail
        "Sua senha foi redefinida para ${senhaTemp}.".toString()
    }

    @PatchMapping('/api/cliente/alterarSenha')
    String alterarSenha(@RequestBody Cliente obj) {
        // Mantido igual ao backend Java original: o campo "documento" é usado
        // como senha antiga (antigaSenha) na query.
        if (bd.alterarSenha(obj.senha, obj.documento, obj.email) == 0) {
            throw new RegraNegocioException('E-mail ou senha atual incorretos.')
        }
        // TODO enviar e-mail
        'Sua senha foi alterada!'
    }
}
