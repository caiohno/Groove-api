package com.ads.lojinha.repository

import com.ads.lojinha.model.Produto
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
interface ProdutoRepository extends JpaRepository<Produto, Integer> {

    @Query(value = 'select * from produto where destaque>0 order by destaque', nativeQuery = true)
    List<Produto> carregaVitrine()

    @Query(value = 'select * from produto where nome like :termo or descritivo like :termo', nativeQuery = true)
    List<Produto> fazerBusca(@Param('termo') String termo)
}
