package com.ads.lojinha

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class LojinhaApplication {

    static void main(String[] args) {
        SpringApplication.run(LojinhaApplication, args)
    }
}
