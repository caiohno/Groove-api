package com.ads.lojinha.model

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int codigo
    String nome
    String telefone
    String documento
    // A senha pode ser enviada para a API, mas nunca é devolvida nas respostas.
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    String senha
    String logradouro
    String email
    int ativo
}
