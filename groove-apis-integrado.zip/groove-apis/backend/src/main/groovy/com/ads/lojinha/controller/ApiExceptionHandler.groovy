package com.ads.lojinha.controller

import com.ads.lojinha.service.RegraNegocioException
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.RestControllerAdvice

@RestControllerAdvice
class ApiExceptionHandler {

    @ExceptionHandler(RegraNegocioException)
    ResponseEntity<Map<String, String>> regraDeNegocio(RegraNegocioException e) {
        ResponseEntity.status(HttpStatus.BAD_REQUEST).body([mensagem: e.message] as Map<String, String>)
    }
}
